---
alias: []
tags: [txt, Space_, Bear, RELEASE_NOTE, audit_, 階段, 人格, 稽核, 指令, ZHIYAN_VERSION]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/智研維護 INDEX（Bear 入口頁｜v3.00.3）.md]
sensitivity: medium
---
# #智研/維護 #智研/INDEX #階段/草稿
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [txt, Space, Bear, 階段, 人格, audit_, reference_, LEGAL_WRITER, CONSULTANT, TUTOR]
- scope: 智研維護 INDEX（Bear 入口頁｜v3.00.3）.md：#智研/維護 #智研/INDEX #階段/草稿
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/智研維護 INDEX（Bear 入口頁｜v3.00.3）.md
- sensitivity: medium
內容：
#智研/維護 #智研/INDEX #階段/草稿

> 更新日期：2026-01-17
> 目前版本（單一真源）：**v3.00.3（審計降噪整合修復版）**
> 送代範圍：僅內部（你＋我）

---

## 0) 快速跳轉（Bear 內部連結）
- [[智研_版本單一真源_ZHIYAN_VERSION]]
- [[智研_發布說明_RELEASE_NOTE]]
- [[智研_冒煙測試_SMOKE_TESTS]]
- [[智研_匯出對照_EXPORT_MAP]]
- [[智研_變更紀錄_CHANGELOG]]

---

## 1) Space 載入硬規則（不可破）
- Space **只允許**載入：`01_上傳到Space_檔案/`
- **嚴禁**載入：`98_audit_稽核/`、`99_reference_勿載入/`
- 「TREE / checksum / 稽核報告 / 版本筆記」一律放 `98` 或 `99`，不可混入 `01`

---

## 2) 載入順序（固定）
- **L0**：核心規格
- **L0.5**：核心閘門／安全協議（SRP）
- **L1**：啟動流程（BOOT）→ 主人格（MASTER）
- **L2**：人格模組（TA / LEGAL_WRITER / WRITER / CONSULTANT / TUTOR）
- **L3**：策略模組（合約風險 / 訴訟推演）
- **L4**：引用政策
- **L5**：模式（REPORT / RESEARCH / QC）

---

## 3) 本次要上傳到 Space 的檔案清單（01_上傳到Space_檔案/）
> Bear 建立「同名筆記」，並加上 `#智研/上傳`
> 匯出時：**檔名＝筆記標題**（最省事、最不會亂）

### L0｜核心規格
- [ ] [[01_智研空間_核心規格_v3.00_HYBRID.md]]

### L0.5｜閘門／安全
- [ ] [[01_核心閘門_ZHIYAN_CORE_GATE.txt]]
- [ ] [[51_模組_安全風險對話處理_SRP_v1.0.txt]]

### L1｜啟動／主人格
- [ ] [[11_啟動流程_BOOT_v2.40.md]]
- [ ] [[10_主人格_MASTER_v2.0.0.md]]

### L2｜人格
- [ ] [[40_人格_助教批改_TA.txt]]
- [ ] [[41_人格_文書_LEGAL_WRITER.txt]]
- [ ] [[42_人格_申論寫作_WRITER.txt]]
- [ ] [[43_人格_顧問_CONSULTANT.txt]]
- [ ] [[44_人格_教學_TUTOR.txt]]

### L3｜策略模組
- [ ] [[52_模組_合約風險策略_CONTRACT_RISK.txt]]
- [ ] [[50_模組_訴訟五維推演_LITIGATION.txt]]

### L4｜引用政策
- [ ] [[31_引用政策_CITATION_POLICY_v2.0.md]]

### L5｜模式
- [ ] [[22_模式_QC_查核_v2.0.md]]
- [ ] [[21_模式_RESEARCH_研究_v2.0.md]]
- [ ] [[20_模式_REPORT_報告_v2.0.md]]

---

## 4) Bear 標籤（全中文，簡單好懂）
> 只用這四個就夠：上傳／指令／稽核／參考
> 再加階段：草稿→檢視→QC→發布

- `#智研/上傳`：要匯出到 `01_上傳到Space_檔案/`
- `#智研/指令`：要匯出到 `00_貼到Space_指令/`
- `#智研/稽核`：只放 `98_audit_稽核/`（Space 不載入）
- `#智研/參考`：只放 `99_reference_勿載入/`（Space 不載入）
- 階段：
  - `#階段/草稿` `#階段/檢視` `#階段/QC` `#階段/發布`

---

## 5) 每個「上傳檔」筆記的檔頭模板（直接貼在每則筆記最上面）
> 提醒：Bear 筆記標題就用檔名（含副檔名），這樣匯出最省事
---

---
### Chunk 02
- chunk_id: 02
- keywords: [RELEASE_NOTE, txt, Space_, 例如, SMK, SOP, ZHIYAN_VERSION, SMOKE_TESTS, release, zip]
- scope: 智研維護 INDEX（Bear 入口頁｜v3.00.3）.md：#智研/維護 #智研/INDEX #階段/草稿
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/智研維護 INDEX（Bear 入口頁｜v3.00.3）.md
- sensitivity: medium
內容：
### 模板（複製後改〈 〉）
- 文件ID：〈檔名（同筆記標題）〉
- 版本：**v3.00.3**
- 層級：〈L0 / L0.5 / L1 / L2 / L3 / L4 / L5〉
- 上游相依：〈例如：核心規格、核心閘門〉
- 下游影響：〈例如：所有人格、模式輸出〉
- 變更摘要：
  - [ ] 〈一句話：這次改什麼〉
- 測試要求（SMK 編號）：〈例如：SMK-04、SMK-07〉
- 回滾指引：退回到〈上一版號〉同名檔

---

## 6) 送代 SOP（你只要照這 6 步）
1. 更新 [[智研_版本單一真源_ZHIYAN_VERSION]]
2. 更新本頁（版本／日期／要上傳清單）
3. 逐檔補齊檔頭模板（至少：版本、層級、測試要求）
4. 執行 [[智研_冒煙測試_SMOKE_TESTS]]（勾選＋備註）
5. 匯出：
   - `#智研/指令` → `00_貼到Space_指令/`
   - `#智研/上傳` → `01_上傳到Space_檔案/`
6. 填 [[智研_發布說明_RELEASE_NOTE]]，然後打包 release zip（含 00/01/98/99）

---

## 7) 稽核附件（放 98_audit_稽核/）
- `TREE_結構地圖.txt`
- `SHA256SUMS.txt`
- `RELEASE_NOTE.md`（對應：[[智研_發布說明_RELEASE_NOTE]]）
- （可選）`manifest.txt`：列出本次 01 資料夾檔案清單

---

## 8) 匯出對照（寫死，避免每次重想）
詳見：[[智研_匯出對照_EXPORT_MAP]]

---

## 9) 變更紀錄（長期累積）
詳見：[[智研_變更紀錄_CHANGELOG]]
---

## 原文關鍵摘錄
- "#智研/維護 #智研/INDEX #階段/草稿"
- "> 更新日期：2026-01-17"
- "> 目前版本（單一真源）：**v3.00.3（審計降噪整合修復版）**"
- "> 送代範圍：僅內部（你＋我）"
- "---"
- "## 0) 快速跳轉（Bear 內部連結）"
- "- [[智研_版本單一真源_ZHIYAN_VERSION]]"
