---
alias: []
tags: [mermaid, flowchart, 系統流程圖, 文字版, 使用者輸入, 題目, 案件資料, 選任務入口, 申論題入口, 法律報告入口]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip, 智研x法言_最終整合包_v1.9.3/00_總覽與索引/FLOWCHART_流程圖.md]
sensitivity: medium
---
# 系統流程圖（文字版）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [mermaid, flowchart, 系統流程圖, 文字版, 使用者輸入, 題目, 案件資料, 選任務入口, 申論題入口, 法律報告入口]
- scope: FLOWCHART_流程圖.md：系統流程圖（文字版）
- content_type: procedure
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/00_總覽與索引/FLOWCHART_流程圖.md
- sensitivity: medium
內容：
# 系統流程圖（文字版）

```mermaid
flowchart TD
    A[使用者輸入/題目/案件資料] --> B{選任務入口}
    B --> C1[申論題入口]
    B --> C2[法律報告入口]
    B --> C3[合約審查入口]
    B --> C4[訴訟文件入口]
    B --> C5[客戶函件入口]
    B --> C6[消費申訴入口]

C1 --> G[法言工作模組]
    C2 --> G
    C3 --> G
    C4 --> G
    C5 --> G
    C6 --> G

G --> H[語言控制/在地化]
    H --> I[可信度分層/風險燈號]
    I --> J[品質控制(反向思考)]
    J --> K[強制驗證]
    K --> L{紅線守護}
    L -->|通過| M[輸出(交付/探索/敘事)]
    L -->|不通過| N[告知缺口/補救指引]

M --> O[完成/自動存檔(需要時)]
```
---

## 原文關鍵摘錄
- "# 系統流程圖（文字版）"
- "```mermaid"
- "flowchart TD"
- "A[使用者輸入/題目/案件資料] --> B{選任務入口}"
- "B --> C1[申論題入口]"
- "B --> C2[法律報告入口]"
- "B --> C3[合約審查入口]"
