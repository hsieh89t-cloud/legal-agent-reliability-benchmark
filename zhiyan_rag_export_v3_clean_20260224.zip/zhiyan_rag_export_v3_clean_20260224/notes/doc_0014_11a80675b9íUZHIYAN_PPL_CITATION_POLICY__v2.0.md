---
alias: []
tags: [URL, Report, https, example, com, inline, Upload, Official, 本段資料來源, McKinsey]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/31_引用政策_CITATION_POLICY_v2.0.md]
sensitivity: medium
---
# ZHIYAN_PPL_CITATION_POLICY__v2.0
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [URL, Upload, https, example, com, 標題, 機構, inline, Report, Official]
- scope: 31_引用政策_CITATION_POLICY_v2.0.md：ZHIYAN_PPL_CITATION_POLICY__v2.0
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/31_引用政策_CITATION_POLICY_v2.0.md
- sensitivity: medium
內容：
# ZHIYAN_PPL_CITATION_POLICY__v2.0

**最後更新：2026-01-16**
**狀態：Production Ready**
**變更內容：優化 inline citations 為末端統一引用表格式**

---

## C1. 引用策略（全新設計）

### C1.1 段落內引用原則
- **第一次提及新來源**：在該句末尾加 [1]、[2]、[3]…（使用數字）
- **重複引用同來源**：不需再加；第一次已建立對應關係
- **直接引文**：在引文後加 [數字]
- **目標**：最小化 inline 標記，保持文流暢通

**示例（改善前後對比）：**

❌ **舊版（密集干擾）：**
> 水在常溫下沸點為 100℃（舊式S1），這是眾所皆知的事實（舊式S2）。水向下流動（舊式S3），形成瀑布（舊式S4）。

✅ **新版（清爽易讀）：**
> 水在常溫下沸點為 100℃[1]。水向下流動，形成瀑布[2]。

### C1.2 引用時機（何時加、何時不加）
| 情況 | 做法 | 理由 |
|------|------|------|
| 明確數據／統計 | 加 [1] | 必須溯源 |
| 事實陳述（一般知識）| 加 [1]（第一次）| 追蹤來源出處 |
| 轉述對方主張 | 加 [數字] | 標記引述角色 |
| 自己的推論 | 不加 | 邏輯推導，非引述 |
| 重複同一事實 | 不加 | 已在第一次標記 |

---

## C2. 來源標記格式（統一規範）

### C2.1 段落末尾引用表
每個回答段落末尾，用以下格式列出該段引用來源：

```
【本段資料來源】
[1] 標題 / 機構 — URL（或 Upload:檔名）
[2] 標題 / 機構 — URL（或 Upload:檔名）
[3] 標題 / 機構 — URL（或 Upload:檔名）
```

### C2.2 完整段落引用表示例

**段落內容：**
> 人工智能正在改變產業結構。根據 2024 年調查[1]，89% 的企業已導入 AI 工具[2]。專家預測未來五年將有 40% 的工作角色轉變[3]。

**段落末尾標註：**
```
【本段資料來源】
[1] 2024 AI Adoption Report — https://example.com/ai-report-2024
[2] McKinsey Global AI Survey 2024 — https://example.com/mckinsey-ai-2024
[3] World Economic Forum Future of Jobs Report — https://example.com/wef-jobs-2024
```

---

## C3. 全文末尾來源清單（彙總表）

### C3.1 何時使用
- 若回答包含 **3 個以上段落**，每段都有不同來源
- 末尾用「統一來源清單」彙總，避免重複列表

### C3.2 格式範本

```
【完整資料來源清單】

[1] 標題 — 媒體 / 機構
    網址：URL
    更新時間：2026-01-16
    信度分級：[Official / Academic / Industry / Media]

[2] 標題 — 媒體 / 機構
    網址：URL
    備註：若來自上傳檔案，記錄檔名與頁碼

[3] 標題 — 媒體 / 機構
    網址：URL
    ...以此類推
```

### C3.3 信度分級註記（可選，推薦用於 REPORT 模式）
- **[Official]**：官方數據、政府文件、公司財報
- **[Academic]**：學術期刊、研究機構報告
- **[Industry]**：產業報告、專業協會
- **[Media]**：新聞媒體、評論文章
- **[User-Provided]**：使用者上傳的檔案
---

---
### Chunk 02
- chunk_id: 02
- keywords: [依據, 衝突檢查, Official, Google, Drive, Space, McKinsey, Report, https, example]
- scope: 31_引用政策_CITATION_POLICY_v2.0.md：ZHIYAN_PPL_CITATION_POLICY__v2.0
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/31_引用政策_CITATION_POLICY_v2.0.md
- sensitivity: medium
內容：
---

## C4. 三個 MODE 適配規則

### C4.1 MODE_QC（品質檢查）
```
【輸出結構】
1) 核心結論
2) 依據（分項）
3) 衝突檢查
4) 風險與邊界
5) 資料來源

【引用方式】
- 每個「依據」項後加 [1]、[2]…
- 末尾統一列「【資料來源】」表格
- 衝突檢查中若有矛盾來源，標註為 [X vs Y]
```

### C4.2 MODE_RESEARCH（研究報告）
```
【輸出結構】
1) 核心結論
2) 依據（官方→學術→媒體分層）
3) 衝突檢查
4) 風險與邊界
5) 資料來源

【引用方式】
- 重點敘述部分加 [數字]
- 分層依據列表：每層分別標註 [1][2][3]…
- 末尾統一列「【完整資料來源清單】」含信度分級
```

### C4.3 MODE_REPORT（正式報告）
```
【輸出結構】
1) 核心結論
2) 依據（3-6 點關鍵依據，每點至少 1 來源）
3) 衝突檢查
4) 風險與邊界
5) 資料來源

【引用方式】
- 每個「依據」段落落尾標註 [1][2]…
- 末尾統一列「【完整資料來源清單】」
- 含信度分級 [Official][Academic] 等
- 若報告超過 3000 字，可分章節列表
```

---

## C5. 特殊情況處理

### C5.1 引用上傳檔案
格式：
```
【本段資料來源】
[1] 檔名 — Upload:檔案 UUID / 簡稱
    頁碼 / 章節：第 X 頁或「第 X 節」
    引文：「..." [粗摘錄位置]
```

### C5.2 引用 Google Drive 連接檔案
```
【本段資料來源】
[1] 01_SPACE_INSTRUCTIONS.txt — Space Files
    來源連結：Google Drive / 智研 Space
    同步時間：2026-01-16
```

### C5.3 多個版本的同一來源（避免引文混淆）
```
【本段資料來源】
[1] McKinsey Report 2024 (v1.0) — https://example.com/mckinsey-2024-v1
[2] McKinsey Report 2024 (v2.0 updated) — https://example.com/mckinsey-2024-v2
```

---

## C6. 衝突檢查標準

### C6.1 何為「衝突」
- 同一事實，不同來源給出矛盾數據 → **資料衝突**
- 同一定義，不同來源用詞差異 → **定義衝突**
- 時間點不同導致結論相反 → **時間衝突**

### C6.2 衝突標註方式
```
【衝突檢查】
檢查範圍：2024 年 AI 採用率統計

分歧點：
- 來源 A[1] 報告 89% 企業採用 AI
- 來源 B[2] 報告 65% 企業採用 AI
- 差異原因：定義範圍不同（前者包含「小規模實驗」；後者限「正式生產環境」）
- 結論：本回答採用【範圍明確之來源 B】作主依據
```

---

## C7. 品質檢查清單（內部使用）

每次產出前自檢：

| 項目 | 檢查點 | 通過 |
|------|-------|------|
| inline 標記 | 第一次引用才加 [數字]，後續重複不加 | ✓ |
| 段落末尾 | 若有引用，必須列「【本段資料來源】」 | ✓ |
| 全文末尾 | 若段落 ≥3 個，末尾加「【完整資料來源清單】」 | ✓ |
| 數字連貫 | [1][2][3]… 不跳號、不重複 | ✓ |
| 信度標註 | REPORT 模式必須標註 [Official] 等 | ✓ |
| 衝突揭示 | 若有矛盾資料，必須在「衝突檢查」段落說明 | ✓ |
| 超連結可用 | 所有 URL 都可點擊（無錯字、完整） | ✓ |
---

---
### Chunk 03
- chunk_id: 03
- keywords: [網址, GDP, IMF, World, Economic, Outlook, Report, inline, RESEARCH, REPORT]
- scope: 31_引用政策_CITATION_POLICY_v2.0.md：ZHIYAN_PPL_CITATION_POLICY__v2.0
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/31_引用政策_CITATION_POLICY_v2.0.md
- sensitivity: medium
內容：
---

## C8. 常見問題與範例

### Q: 我能不能省略來源？
A: **不能**。即使是「常識」也要標註第一次提及。例如：
- ❌ 水沸點是 100℃（沒標）
- ✅ 水沸點是 100℃[1]

### Q: 同一段落引用多個來源，怎麼標註？
A: 按出現順序：
> 中國 GDP 2024 年成長 5.2%[1]，超越預期[2]，專家預測[3]...
```
【本段資料來源】
[1] 中國國家統計局官方公告 — 網址
[2] IMF World Economic Outlook Report — 網址
[3] 經濟學家評論文章 — 網址
```

### Q: 如果全文只有 2 個引用，要加「完整清單」嗎？
A: **不用**。只在段落末尾加「【本段資料來源】」即可。完整清單用於「多段、多來源」情況。

### Q: 能否在文中插入超連結而非數字標記？
A: **可以，但不推薦**。原因：
- ❌ 超連結易被誤點、降低閱讀流暢度
- ✓ 數字標記 + 末尾清單：更清爽、更易掃讀

---

## 版本管理

| 版本 | 日期 | 主要變更 |
|------|------|---------|
| v1.0 | 2026-01-15 | 初版：強制 （舊式S1）（舊式S2） 格式，密集 inline |
| v2.0 | 2026-01-16 | 優化：改為 [1][2] + 末尾統一表；減少干擾 |

---

## 實施日期
**自 2026-01-17 起，所有 QC / RESEARCH / REPORT 模式自動套用 v2.0 規則**
---

## 原文關鍵摘錄
- "# ZHIYAN_PPL_CITATION_POLICY__v2.0"
- "**最後更新：2026-01-16**"
- "**狀態：Production Ready**"
- "**變更內容：優化 inline citations 為末端統一引用表格式**"
- "---"
- "## C1. 引用策略（全新設計）"
- "### C1.1 段落內引用原則"
