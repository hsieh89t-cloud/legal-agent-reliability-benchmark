---
alias: []
tags: [重要, class, chatgpt_plugin, role, span, README, txt, assistant, style, font-size]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/未命名.md]
sensitivity: medium
---
# <hr class="__chatgpt_plugin">
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [重要, class, chatgpt_plugin, role, span, README, txt, assistant, style, font-size]
- scope: 未命名.md：<hr class="__chatgpt_plugin">
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/未命名.md
- sensitivity: medium
內容：
<hr class="__chatgpt_plugin">

### role::assistant<span style="font-size: small;"> (qwen2.5:7b)</span>

<hr class="__chatgpt_plugin">

### role::user

📁 智研法學資料庫/
│
├─ 📁 01_現用版本（當前工作）
│  ├─ 01_核心檔案/          ← 重要✅
│  ├─ 02_人格模組/          ← 重要✅
│  ├─ 03_策略模組/          ← 重要✅
│  ├─ 04_引用政策/          ← 重要✅
│  └─ 05_品質檢查/          ← 重要✅
│
├─ 📁 02_測試版本（微調中）
│  ├─ 微調_v2.0/
│  ├─ 微調_v2.1/
│  └─ README.txt           ← 寫明每版做了什麼
│
├─ 📁 03_舊版本（歸檔）
│  ├─ v1.0_舊/
│  ├─ v2.0_舊/
│  └─ README.txt
│
└─ 📁 99_草稿與備份
   ├─ 想法筆記/
   └─ 臨時檔案/
---

## 原文關鍵摘錄
- "<hr class="__chatgpt_plugin">"
- "### role::assistant<span style="font-size: small;"> (qwen2.5:7b)</span>"
- "<hr class="__chatgpt_plugin">"
- "### role::user"
- "📁 智研法學資料庫/"
- "│"
- "├─ 📁 01_現用版本（當前工作）"
