---
alias: []
tags: [type, string, description, true, array, case_no, stability, weight, url, json]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip, 智研x法言_最終整合包_v1.9.3/00_總覽與索引/MODULE39_BEFORE_AFTER.md]
sensitivity: medium
---
# 39_判例檢索與可交付格式模組 變更合併（Before + After）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [type, string, description, array, true, json, log, case_no, stability, weight]
- scope: MODULE39_BEFORE_AFTER.md：39_判例檢索與可交付格式模組 變更合併（Before + After）
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/00_總覽與索引/MODULE39_BEFORE_AFTER.md
- sensitivity: medium
內容：
# 39_判例檢索與可交付格式模組 變更合併（Before + After）

## Before（原內容）
```json
{
  "meta": {
    "module_id": "39",
    "name": "判例檢索與可交付格式模組",
    "version": "1.4",
    "owner": "育昇法務｜法言×智研",
    "purpose": "把『判例』轉成可交付、可回溯、可稽核的格式（含webID/穩定度/權重/摘要/連結），並輸出可觀測log。",
    "non_goal": "本模組不負責決定是否需要查判例；是否需要由任務入口或38模組決定。",
    "binding_note": "正式交付涉及法律爭點時，39必須與38同時載入（缺一即中止輸出）。"
  },
  "inputs": {
    "legal_issues": {
      "type": "array",
      "min_items": 1,
      "description": "法律爭點清單（每一爭點至少對應一則判決；若無，須明示『無穩定實務／需補查』）。"
    },
    "queries": {
      "type": "array",
      "description": "每爭點對應的檢索關鍵字或查詢式（可空，但需在log說明原因）。",
      "allow_empty": true
    },
    "raw_results": {
      "type": "array",
      "description": "判例檢索原始結果（手動整理/外部工具/資料庫輸入皆可）。",
      "allow_empty": true
    }
  },
  "outputs": {
    "case_law_structured": {
      "type": "array",
      "schema": {
        "web_id": "string",
        "court_level": "string",
        "case_no": "string",
        "stability": "string",
        "weight": "integer",
        "holding": "string",
        "url": "string"
      }
    },
    "case_law_block": {
      "type": "markdown",
      "description": "可直接貼入交付文件的【相關判決】區塊。"
    },
    "observability_log": {
      "type": "object",
      "description": "可觀測紀錄（對應 DEBUG_判例查詢可觀測規格.json）。"
    }
  },
  "rules": {
    "hard_require_with_38": true,
    "min_cases_per_issue": 1,
    "required_fields": [
      "web_id",
      "court_level",
      "case_no",
      "stability",
      "weight",
      "holding",
      "url"
    ],
    "stability_scale": {
      "穩定🟢": "多數實務一致或有最高法院/大法庭穩定見解",
      "分歧🟡": "見解分歧或法院層級/理由存在顯著差異",
      "新興🔵": "新近趨勢但尚未形成穩定路線",
      "未知⚪": "資料不足或無法判斷"
    },
    "weight_guidance": [
      "最高法院/大法庭/憲法法庭且見解一致：90-99",
      "高等法院層級且與多數見解一致：80-89",
      "地方法院或見解分歧：60-79",
      "資料不足：50-59並標示未知⚪"
    ],
    "output_format": {
      "title": "【相關判決】",
      "template": [
        "- 司法院webID：{case_no}（權重{weight}%）",
        "- 見解：{stability}",
        "- 核心見解摘要：{holding}",
        "- 連結：{url}"
      ],
      "notes": [
        "正式文章正文禁止Emoji；此處符號僅作『穩定度標示』使用。",
        "若無可用判決：輸出『無穩定實務／需補查』並在log記錄原因。"
      ]
    },
    "observability": {
      "required": true,
      "schema_ref": "DEBUG_判例查詢可觀測規格.json",
      "min_fields": [
        "timestamp_taipei",
        "issue",
        "query_terms",
        "status",
        "hits",
        "note"
      ]
    }
  }
}
```
---

---
### Chunk 02
- chunk_id: 02
- keywords: [type, string, description, array, json, webID, log, case_law_structured, case_law_block, allow_empty]
- scope: MODULE39_BEFORE_AFTER.md：39_判例檢索與可交付格式模組 變更合併（Before + After）
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/00_總覽與索引/MODULE39_BEFORE_AFTER.md
- sensitivity: medium
內容：
## After（雙輸出＋固定格式區塊）
```json
{
  "meta": {
    "module_id": "39",
    "name": "判例檢索與可交付格式模組",
    "version": "1.
4.
1",
    "owner": "育昇法務｜法言×智研",
    "purpose": "把『判例』轉成可交付、可回溯、可稽核的格式（含webID/穩定度/權重/摘要/連結），並輸出可觀測log。
",
    "non_goal": "本模組不負責決定是否需要查判例；是否需要由任務入口或38模組決定。
",
    "binding_note": "正式交付涉及法律爭點時，39必須與38同時載入（缺一即中止輸出）。
",
    "update_note": "新增『雙輸出』強化：case_law_structured + case_law_block（固定格式區塊），以利零記憶交付一致性；保留 structured 供未來 App/系統重排版。
"
  },
  "inputs": {
    "legal_issues": {
      "type": "array",
      "min_items": 1,
      "description": "法律爭點清單（每一爭點至少對應一則判決；若無，須明示『無穩定實務／需補查』）。
"
    },
    "queries": {
      "type": "array",
      "description": "每爭點對應的檢索關鍵字或查詢式（可空，但需在log說明原因）。
",
      "allow_empty": true
    },
    "raw_results": {
      "type": "array",
      "description": "判例檢索原始結果（手動整理/外部工具/資料庫輸入皆可）。
",
      "allow_empty": true
    }
  },
  "outputs": {
    "case_law_structured": {
      "type": "array",
      "schema": {
        "web_id": "string",
        "court_level": "string",
        "case_no": "string",
        "stability": "string",
        "weight": "integer",
        "holding": "string",
        "url": "string"
      }
    },
    "case_law_block": {
      "type": "markdown",
      "description": "固定交付格式區塊（可直接貼入文件），標題【相關判決】；每筆判決以三行呈現：webID(含權重)、見解(含穩定度)、連結。
"
    },
    "observability_log": {
      "type": "object",
      "description": "可觀測紀錄（對應 DEBUG_判例查詢可觀測規格.
json）。
---

---
### Chunk 03
- chunk_id: 03
- keywords: [true, court_level, case_no, stability, weight, url, webID, hard_require_with_38, min_cases_per_issue, required_fields]
- scope: MODULE39_BEFORE_AFTER.md：39_判例檢索與可交付格式模組 變更合併（Before + After）
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/00_總覽與索引/MODULE39_BEFORE_AFTER.md
- sensitivity: medium
內容：
"
    }
  },
  "rules": {
    "hard_require_with_38": true,
    "min_cases_per_issue": 1,
    "required_fields": [
      "web_id",
      "court_level",
      "case_no",
      "stability",
      "weight",
      "holding",
      "url"
    ],
    "stability_scale": {
      "穩定🟢": "多數實務一致或有最高法院/大法庭穩定見解",
      "分歧🟡": "見解分歧或法院層級/理由存在顯著差異",
      "新興🔵": "新近趨勢但尚未形成穩定路線",
      "未知⚪": "資料不足或無法判斷"
    },
    "weight_guidance": [
      "最高法院/大法庭/憲法法庭且見解一致：90-99",
      "高等法院層級且與多數見解一致：80-89",
      "地方法院或見解分歧：60-79",
      "資料不足：50-59並標示未知⚪"
    ],
    "output_format": {
      "title": "【相關判決】",
      "item_template": [
        "- 司法院webID：{case_no}（權重{weight}%）",
        "- 見解：{court_level}{stability}",
        "- 連結：{url}"
      ],
      "field_mapping": {
        "case_no": "年度字號/ webID（例：114年度XX刑字第X號）",
        "court_level": "法院層級（例：最高法院/高等法院/地方法院）",
        "stability": "穩定度符號（例：穩定🟢/分歧🟡/新興🔵/未知⚪）",
        "weight": "可依賴程度 50-99（%）",
        "url": "司法院法學資料檢索或裁判書頁面連結"
      },
      "notes": [
        "正式文章正文禁止Emoji；此處『穩定度符號』屬標示用途，允許保留。
",
        "若某爭點查無可用判決：該爭點仍需輸出『無穩定實務／需補查』並在可觀測log記錄原因。
"
      ]
    },
    "observability": {
      "required": true,
      "schema_ref": "DEBUG_判例查詢可觀測規格.
json",
      "min_fields": [
        "timestamp_taipei",
        "issue",
        "query_terms",
        "status",
        "hits",
        "note"
      ]
    },
    "dual_output": {
      "enabled": true,
      "structured_for": "系統內部（風險/可信度/品質/存檔/工程重排版）",
      "block_for": "人類交付（貼上即用）"
    },
    "formal_delivery_requires_block": true
  }
}
```
---

## 原文關鍵摘錄
- "# 39_判例檢索與可交付格式模組 變更合併（Before + After）"
- "## Before（原內容）"
- "```json"
- "{"
- ""meta": {"
- ""module_id": "39","
- ""name": "判例檢索與可交付格式模組","
