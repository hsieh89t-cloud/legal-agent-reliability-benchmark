---
alias: []
tags: [Style, 適用, 特徵, 例句, Academic, Legal, Writing, Compendium, Judicial, Analytical]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip > 法務智研_FINAL_v1.8_規格強化包.zip, 法務智研文筆風格總覽.docx]
sensitivity: medium
---
# 法務智研文筆風格總覽（Legal Writing Style Compendium）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [Style, 適用, 特徵, 例句, Academic, Legal, Writing, Compendium, Judicial, Analytical]
- scope: 法務智研文筆風格總覽.docx：法務智研文筆風格總覽（Legal Writing Style Compendium）
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip > 法務智研_FINAL_v1.8_規格強化包.zip:法務智研文筆風格總覽.docx
- sensitivity: medium
內容：
法務智研文筆風格總覽（Legal Writing Style Compendium）
一、正式法學論述風格（學術型 Academic Style）
🎯 適用：教授、法官、法學院報告、期刊。
💬 特徵：嚴謹、引用多、句式長、重邏輯層次。

- 第三人稱書寫，避免主觀語氣。
- 引用法律條文、釋字、判例與學說。
- 結構：「前提—推論—結論」。
- 常用詞：依據、原則、構成要件、體系。

例句：刑法第235條之適用範圍，應受憲法第11條講學自由之限制。
二、司法實務風格（法院用語型 Judicial Style）
🎯 適用：判決書、檢察官起訴書、辯護狀。
💬 特徵：條理清晰、中立客觀、強調事實。

- 採「事實—法律—結論」三段論法。
- 用語：茲查、爰認定、依此可見。
- 語句不帶情感，不用修辭。

例句：查被告所為，尚難認已具公然性，爰不構成本罪。
三、研究報告風格（分析型 Analytical Style）
🎯 適用：研究計畫、政策建議、學期報告。
💬 特徵：條列明確、邏輯分析、有理有據。

- 每段開頭設主題句。
- 段落連貫性高，常用「再者、此外」銜接。
- 結合條文與社會分析。

例句：AI判決預測系統之透明性不足，可能違反正當程序原則。
四、通俗法律寫作風格（普及型 Public Style）
🎯 適用：媒體文章、法律教育、通識課程。
💬 特徵：語言親切、比喻生動、短句多。

- 避免艱澀詞彙。
- 用例子說明法律觀念。
- 可用問句引導思考。

例句：法律禁止「猥褻」內容，但什麼是猥褻？只要有教育或藝術價值，就不會被定罪。
五、哲學反思型（思辨型 Reflective Style）
🎯 適用：AI倫理、法哲學、演講稿結語。
💬 特徵：修辭性高、具詩意與哲理深度。

- 可用排比、對比句。
- 強調價值與意象。
- 融合法理與人文語感。

例句：演算法不會懷疑，正因如此，人類才需保留懷疑的勇氣。
六、策略型行文風（Forensic-Analytic Style）
🎯 適用：法律申論題、法理討論、判決評論。
💬 特徵：理性、穩定、邏輯強、具分析深度。

📐 結構規範：
1️⃣ 三段式邏輯（問題界定→理論分析→立場收斂）。
2️⃣ 每段5–7行，每行約25±5字。
3️⃣ 全文500–700字。

💬 語氣與句式：
- 「雖然……但仍……」
- 「應以……為原則」
- 「由此觀之，可見……」

📘 起承轉合語：
起：有鑑於此、關於此問題
轉：然而、但仍、惟須注意
合：是以、由此可見、可見其然。

📏 技術規格：
理性90%、情感5%、節奏5%。
繁體中文（zh-TW），Formal Academic Prose。
---

## 原文關鍵摘錄
- "法務智研文筆風格總覽（Legal Writing Style Compendium）"
- "一、正式法學論述風格（學術型 Academic Style）"
- "🎯 適用：教授、法官、法學院報告、期刊。"
- "💬 特徵：嚴謹、引用多、句式長、重邏輯層次。"
- "- 第三人稱書寫，避免主觀語氣。"
- "- 引用法律條文、釋字、判例與學說。"
- "- 結構：「前提—推論—結論」。"
