---
alias: []
tags: [json, 新增, CHANGELOG, Patch, STEP02_PERSONALITY_ROUTING, Markdown, Emoji, STEP03_ARGUMENT_ORDER, visual_aid, 控制]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip, 智研x法言_最終整合包_v1.9.3/00_總覽與索引/CHANGELOG_v1.9.5_patch.txt]
sensitivity: medium
---
# CHANGELOG｜v1.9.5 Patch（在 v1.9.3 基礎上補丁）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [json, 新增, CHANGELOG, Patch, STEP02_PERSONALITY_ROUTING, Markdown, Emoji, STEP03_ARGUMENT_ORDER, visual_aid, 控制]
- scope: CHANGELOG_v1.9.5_patch.txt：CHANGELOG｜v1.9.5 Patch（在 v1.9.3 基礎上補丁）
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/00_總覽與索引/CHANGELOG_v1.9.5_patch.txt
- sensitivity: medium
內容：
# CHANGELOG｜v1.9.5 Patch（在 v1.9.3 基礎上補丁）

## 變更摘要
1. 新增 00_控制中心_v1.9.3.json：
   - 新增 STEP02_PERSONALITY_ROUTING > 國考申論模式（純文字、無Markdown/Emoji/數字標號、2500±50字、符號限制）
   - 新增 STEP03_ARGUMENT_ORDER > 貪污案件論證順序（主觀→客體→程序緩衝）
   - 定版驗證政策：法條必做、判例加分

2. 新增 32_自然段落波動控制_v1.0.json：
   - 長短段落節奏控制、去AI味規則
   - 增補「廢棄物法律定性」精準化補丁（廢清法第2條+民法第940條比較框架）

3. 新增 47_判例自動檢索模組_v1.0.json：
   - 司法院關鍵詞生成與輸出格式（【】「」→（））
   - 最低要求：1最高法院+1高院（若可得）；否則標示無穩定實務

4. 新增 48_檢方攻擊模組_v1.0.json：
   - 專業批評語氣下的攻防模板（估價、比例、資源）

5. 更新 41_深度顧問引擎_v2.0_台灣在地化.json：
   - 新增「優化結構模板：貪污無罪辯護」章節模板
   - 新增 visual_aid（國考申論附件化圖表規格）

## 備註
- 因既有 33/34 編號已被「可信度分層/自我懷疑」占用，本次新增「判例自動檢索」「檢方攻擊」以 47/48 編號避免衝突。
---

## 原文關鍵摘錄
- "# CHANGELOG｜v1.9.5 Patch（在 v1.9.3 基礎上補丁）"
- "## 變更摘要"
- "1. 新增 00_控制中心_v1.9.3.json："
- "- 新增 STEP02_PERSONALITY_ROUTING > 國考申論模式（純文字、無Markdown/Emoji/數字標號、2500±50字、符號限制）"
- "- 新增 STEP03_ARGUMENT_ORDER > 貪污案件論證順序（主觀→客體→程序緩衝）"
- "- 定版驗證政策：法條必做、判例加分"
- "2. 新增 32_自然段落波動控制_v1.0.json："
