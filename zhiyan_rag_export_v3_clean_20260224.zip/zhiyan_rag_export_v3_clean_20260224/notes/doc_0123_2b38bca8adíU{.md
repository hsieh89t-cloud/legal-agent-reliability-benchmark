---
alias: []
tags: [gov, true, mandatory, name, domain, moj, weight, json, file, judicial]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip, 智研x法言_最終整合包_v1.9.3/03_規範守門_智研/38_強制驗證模組_v1.7.json]
sensitivity: medium
---
# {
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [gov, true, mandatory, name, domain, moj, weight, STEP_03_PRE, law, judicial]
- scope: 38_強制驗證模組_v1.7.json：{
- content_type: principle
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/03_規範守門_智研/38_強制驗證模組_v1.7.json
- sensitivity: medium
內容：
{
  "module_id": "38_強制驗證模組_v1.
7",
  "module_name": "強制驗證模組_v1.
7（官方來源優先）",
  "version": "1.
7",
  "create_date": "114年12月31日",
  "author": "育昇總務課法言系統",
  "total_control_link": "00_控制中心_v1.
6+完整版.
json[file:1]",
  "priority": "STEP_03_PRE",
  "personality": {
    "SCHOLAR": 0.
8,
    "LITIGATOR": 0.
15,
    "EDUCATOR": 0.
05
  },
  "temperature_range": "0.
25-0.
35",
  "execution_pipeline": [
    "STEP_01:來源可訪問性測試",
    "STEP_02:官方優先排序",
    "STEP_03:條文逐條驗證",
    "STEP_04:數據交叉核實",
    "STEP_05:QC分數計算"
  ],
  "official_source_priority": {
    "priority_1": {
      "name": "全國法規資料庫",
      "domain": "law.
moj.
gov.
tw",
      "weight": 100,
      "mandatory": true
    },
    "priority_2": {
      "name": "司法院法學資料",
      "domain": "judicial.
gov.
tw",
      "weight": 95,
      "mandatory": true
    },
    "priority_3": {
      "name": "警政署/法務部統計",
      "domain": [
        "npa.
gov.
tw",
        "moj.
gov.
tw"
      ],
      "weight": 90,
      "mandatory": true
    },
    "priority_4": {
      "name": "立法院公報",
      "domain": "ly.
gov.
tw",
      "weight": 85,
      "mandatory": false
    },
    "exclude_domains": [
      "商業律師網站",
      "新聞網站(單一來源)",
      "社群媒體"
    ]
  },
  "validation_rules": {
    "law_article_check": {
      "required_fields": [
        "全國法規連結",
        "最新修法日期",
        "關鍵條文摘錄"
      ],
      "risk_scoring": {
        "無官方連結": -30,
        "連結失效": -50,
        "內容不符": -40,
        "修法日期錯誤": -25
      }
    },
    "data_verification": {
      "stats_source": "警政署/法務部年度統計通報",
      "case_source": "司法院法學資料檢索系統",
      "mandatory_citation": true
    },
    "risk_light_system": {
      "🟢": "官方來源100%可驗證(90%+)",
      "🟡": "需人工確認雙重佐證(70-89%)",
      "🔴": "來源失效或存疑(<70%)"
    }
  },
  "QC_scoring_matrix": {
    "accuracy": 30,
    "completeness": 25,
    "logic": 20,
    "practicality": 15,
    "language": 10,
    "passing_score": 90
  },
  "automation_tools": {
    "url_accessibility_test": {
      "timeout": 5,
      "retry": 3,
      "required_status": 200
    },
    "official_filter": {
      "domain_whitelist": [
        "law.
moj.
gov.
tw",
        "judicial.
gov.
tw",
        "npa.
gov.
tw",
        "moj.
gov.
tw"
      ],
      "auto_replace": true
    }
  },
  "output_template": {
    "條文驗證清單": {
      "format": "|序號|法條|脈絡|驗證狀態|官方摘錄[web:id]|",
      "mandatory": true
    },
    "數據來源驗證": {
      "format": "來源:警政署114年第X週通報[web:ID]",
      "mandatory": true
    },
    "品質分數": "XX/100（六準則明細）"
  },
  "total_control_integration": {
    "hook_point": "STEP_03_PRE",
    "control_file": "00_控制中心_v1.
6+完整版.
---

---
### Chunk 02
- chunk_id: 02
- keywords: [json, true, file, update_command, STEP0035, STEP0138, auto_sync, SOP, STEP_01_, web]
- scope: 38_強制驗證模組_v1.7.json：{
- content_type: principle
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/03_規範守門_智研/38_強制驗證模組_v1.7.json
- sensitivity: medium
內容：
json",
    "update_command": "STEP0035→STEP0138（新增模組38）",
    "auto_sync": true
  },
  "SOP": {
    "STEP_01_來源可訪問性測試": "所有web引用前執行HTTP狀態檢查，失效自動剔除",
    "STEP_02_官方優先排序": "依權重排序，強制替換非官方來源",
    "STEP_03_條文逐條驗證": "生成驗證清單表格，標註風險燈號",
    "STEP_04_數據交叉核實": "警政/法務部雙源驗證關鍵統計",
    "STEP_05_QC分數計算": "六準則自動計分，<90分強制ABC備案"
  },
  "ABC_contingency": {
    "A": "官方來源全驗證通過→直接定稿",
    "B": "部分來源【黃】→人工確認+雙重佐證",
    "C": "【紅】來源失效→重新工具搜尋"
  },
  "stability": "【綠】98%",
  "upload_instruction": "直接複製本JSON，上傳為'38_強制驗證模組_v1.
7.
json'，自動連結總控[file:1]",
  "免責聲明": "本模組確保法律報告準確性，不替代律師專業判斷[file:12]",
  "forced_case_search": {
    "trigger": [
      "output_type=申論"
    ],
    "minimum_cases": 1,
    "mandatory_source": "judicial.
gov.
tw",
    "log_reason": true
  }
}
---

## 原文關鍵摘錄
- "{"
- ""module_id": "38_強制驗證模組_v1.7","
- ""module_name": "強制驗證模組_v1.7（官方來源優先）","
- ""version": "1.7","
- ""create_date": "114年12月31日","
- ""author": "育昇總務課法言系統","
- ""total_control_link": "00_控制中心_v1.6+完整版.json[file:1]","
