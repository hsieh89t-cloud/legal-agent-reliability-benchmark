---
alias: []
tags: [webID, meta, module_id, name, purpose, last_updated, trigger, when, mode_policy, query_builder]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip, 智研x法言_最終整合包_v1.9.3/03_規範守門_智研/47_判例自動檢索模組_v1.0.json]
sensitivity: medium
---
# {
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [webID, meta, module_id, name, purpose, last_updated, trigger, when, mode_policy, query_builder]
- scope: 47_判例自動檢索模組_v1.0.json：{
- content_type: principle
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/03_規範守門_智研/47_判例自動檢索模組_v1.0.json
- sensitivity: medium
內容：
{
  "meta": {
    "module_id": "47",
    "name": "判例自動檢索與整理（司法院關鍵詞版）",
    "version": "v1.0",
    "purpose": "在需要時生成檢索關鍵詞並整理候選判例（以司法院法學資料檢索系統為主）。",
    "last_updated": "2026-01-01"
  },
  "trigger": {
    "when": "出現『法律爭點』且使用者要求高分/正式交付/訴訟文件；或模組38驗證後判定需補強實務",
    "mode_policy": "法條必做、判例加分"
  },
  "query_builder": {
    "default_keywords": "清潔隊員 + 廢棄物 + 侵占 + 貪污 + 最高法院",
    "case_specific_rules": [
      "若案件涉及職務上持有→加入「職務上持有」「非公用」「侵占」",
      "若涉及廢棄物性質→加入「廢棄物清理法」「焚化」「回收」"
    ]
  },
  "source": {
    "primary": "司法院法學資料檢索系統（web/API）",
    "fallback": [
      "司法院司法周刊/大法庭裁定摘要",
      "高等法院裁判下載頁"
    ]
  },
  "output_format": {
    "style": "僅使用【】「」→（）符號；不使用Markdown表格",
    "item_template": "【{法院}{年度}{字別}{號}（webID:{webID}）】要旨：{要旨}（穩定度：{穩定/分歧/新興}）"
  },
  "minimum_requirement": {
    "must": "至少1個最高法院+1個高等法院（若可得）",
    "if_none": "明確標示「未檢得穩定實務」並改以法條/體系/目的解釋補強"
  }
}
---

## 原文關鍵摘錄
- "{"
- ""meta": {"
- ""module_id": "47","
- ""name": "判例自動檢索與整理（司法院關鍵詞版）","
- ""version": "v1.0","
- ""purpose": "在需要時生成檢索關鍵詞並整理候選判例（以司法院法學資料檢索系統為主）。","
- ""last_updated": "2026-01-01""
