---
alias: []
tags: [name, title, LawLevel, LawName, LawURL, LawCategory, LawModifiedDate, LawEffectiveDate, LawEffectiveNote, LawAbandonNote]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 娉曞緥澶у叏.zip, schema.csv]
sensitivity: medium
---
# name,title
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [name, title, LawLevel, LawName, LawURL, LawCategory, LawModifiedDate, LawEffectiveDate, LawEffectiveNote, LawAbandonNote]
- scope: schema.csv：name,title
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 娉曞緥澶у叏.zip:schema.csv
- sensitivity: medium
內容：
name,title
LawLevel,法規位階
LawName,法規名稱
LawURL,法規網址
LawCategory,法規類別
LawModifiedDate,法規異動日期
LawEffectiveDate,生效日期
LawEffectiveNote,生效內容
LawAbandonNote,廢止註記
LawHasEngVersion,是否英譯註記
EngLawName,英文法規名稱
LawAttachements,附件
LawHistories,沿革內容
LawForeword,前言
LawArticles,法條
ArticleType,條文型態
ArticleNo,條號
ArticleContent,條文內容
FileName,檔案名稱
FileURL,下載網址
---

## 原文關鍵摘錄
- "name,title"
- "LawLevel,法規位階"
- "LawName,法規名稱"
- "LawURL,法規網址"
- "LawCategory,法規類別"
- "LawModifiedDate,法規異動日期"
- "LawEffectiveDate,生效日期"
