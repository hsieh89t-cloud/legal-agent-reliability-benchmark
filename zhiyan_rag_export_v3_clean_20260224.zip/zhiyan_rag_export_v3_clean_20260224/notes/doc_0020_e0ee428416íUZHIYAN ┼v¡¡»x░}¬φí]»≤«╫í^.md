---
alias: []
tags: [MASTER, BOOT, REQUIRE, Fact_Check, FAIL, ZHIYAN, Single, Source, Truth, Risk]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/96_權限矩陣_PERMISSION_MATRIX.md]
sensitivity: high
---
# ZHIYAN 權限矩陣表（草案）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [MASTER, BOOT, REQUIRE, Fact_Check, FAIL, ZHIYAN, Single, Source, Truth, Risk]
- scope: 96_權限矩陣_PERMISSION_MATRIX.md：ZHIYAN 權限矩陣表（草案）
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/96_權限矩陣_PERMISSION_MATRIX.md
- sensitivity: high
內容：
# ZHIYAN 權限矩陣表（草案）
> BOOT／人格（L1）／模組（L2）共用的唯一判斷依據（Single Source of Truth）
> 原則：**核心先、路由後、人格/模組最後；缺失事實先補齊，未通過則中止。**

---

## 1) 權限矩陣（初版）

| 輸入條件（Input） | 風險等級（Risk） | 允許人格（L1） | 允許模組（L2） |
|---|---|---|---|
| 名詞／制度解釋（無現案） | 低 | TUTOR | — |
| 申論題（題幹明確） | 中 | WRITER、TA | — |
| 一般問題（需整理回報） | 低～中 | MASTER | — |
| 已驗證事實（可提出多方案） | 中 | CONSULTANT | — |
| 合約文本完整（可起草/審閱） | 中 | LEGAL_WRITER | CONTRACT_RISK（需額外 REQUIRE） |
| 合約不完整（僅能列缺失清單） | 中 | MASTER（缺失清單模式） | — |
| 訴訟現案／攻防推演 | 高 | MASTER（先整理） | LITIGATION（需額外 REQUIRE） |
| 事實缺失（Who/When/Where/What/Result 不足） | 任意 | MASTER（ERROR／補充清單） | — |
| Fact_Check == FAIL | 任意 | MASTER（ERROR_MODE） | — |

---

## 2) 全域硬性規則（不得繞過）

- **BOOT 只允許讀取本矩陣**做決策；不得在各人格自行複寫入口邏輯。
- 任何 L2 模組必須同時滿足：
  - `CORE_GATE_STATUS == PASS`
  - `CONTEXT_COMPLETENESS == TRUE`
  - `MODULE_PERMISSION == GRANTED`
- 若 `Fact_Check == FAIL`：
  - **一律中止所有下游（HALT_ALL_DOWNSTREAM）**
  - 僅允許輸出「錯誤模式／補充清單」
---

## 原文關鍵摘錄
- "# ZHIYAN 權限矩陣表（草案）"
- "> BOOT／人格（L1）／模組（L2）共用的唯一判斷依據（Single Source of Truth）"
- "> 原則：**核心先、路由後、人格/模組最後；缺失事實先補齊，未通過則中止。**"
- "---"
- "## 1) 權限矩陣（初版）"
- "| 輸入條件（Input） | 風險等級（Risk） | 允許人格（L1） | 允許模組（L2） |"
- "|---|---|---|---|"
