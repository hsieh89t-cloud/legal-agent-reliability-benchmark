---
alias: []
tags: [https, example, com, Official, 信度, Industry, 發布時間, Media, 機構, Academic]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/正式報告模板_v2.0.md]
sensitivity: medium
---
# 正式報告模板_v2.0
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [https, example, com, Official, 信度, Industry, 發布時間, Media, 機構, Academic]
- scope: 正式報告模板_v2.0.md：正式報告模板_v2.0
- content_type: template
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/正式報告模板_v2.0.md
- sensitivity: medium
內容：
# 正式報告模板_v2.0

## 用途
適用於撰寫[[正式報告]]，對象為老闆、客戶或主管。
核心結構涵蓋：現況 / 趨勢 / 風險 / 建議 / 結論。

---

## 固定回答結構

### 1) 核心結論
一句話結論：說明當前情況與下一步行動。
適用於忙碌讀者，5 秒內獲取核心訊息。

【本段資料來源】
[1] 主要依據 — URL / 位置

---

### 2) 依據

**3-6 點關鍵依據**（每點至少一個來源）：

1. **現況面**：當前狀況與數據支持[2]
2. **趨勢面**：未來預測與依據[3][4]
3. **風險面**：潛在風險與忽略點[5]
4. **可行性面**：方案可行性與成本估算[6]
5. **對標面**：同業案例或實務比對[7]
6. **法規/限制面**：相關法規與限制[8]

【本段資料來源】
| 序號 | 標題 | 機構 | 網址 | 信度 |
|-----|------|------|------|------|
| [2] | 現況數據 | 機構 | https://example.com | [Official] |
| [3] | 趨勢預測1 | 機構 | https://example.com | [Industry] |
| [4] | 趨勢預測2 | 機構 | https://example.com | [Academic] |
| [5] | 風險警示 | 報告 | https://example.com | [Official] |
| [6] | 方案評估 | 顧問 | https://example.com | [Industry] |
| [7] | 同業案例 | 報導 | https://example.com | [Media] |
| [8] | 法規資訊 | 政府 | https://example.com | [Official] |

---

### 3) 衝突檢查

#### 檢查內容
- 結論：未檢出衝突 / 檢出衝突
- 檢查範圍：比對主要來源清單
- 衝突點（若有）：來源 A 與來源 B 差異與原因
- 建議採用版本：依最新或最高信度來源

【本段資料來源】
[9] 衝突來源 1 — https://example.com
[10] 衝突來源 2 — https://example.com

---

### 4) 風險與邊界

**最可能誤用的注意點**：

- ⚠️ 資料時效性：基於 2026-01-15 前公開資訊，如有重大變化需更新。
- ⚠️ 適用範圍：僅適用於[[台灣市場]]與中型企業；其他情況需調整。

---

### 5) 完整資料來源清單

【完整資料來源清單】

1. [1] 主要依據 — 機構 | https://example.com | 發布時間：2026-01-15 | 信度：[Official]
2. [2] 現況數據 — 統計機構 | https://example.com | 發布時間：2026-01 | 信度：[Official]
3. [3] 趨勢預測1 — 咨詢公司 | https://example.com | 發布時間：2025-12 | 信度：[Industry]
4. [4] 趨勢預測2 — 研究院 | https://example.com | 發布時間：2025-12 | 信度：[Academic]
5. [5] 風險警示 — 行業報告 | https://example.com | 發布時間：2026-01 | 信度：[Official]
6. [6] 方案評估 — 管理咨詢 | https://example.com | 發布時間：2025-11 | 信度：[Industry]
7. [7] 同業案例 — 新聞報導 | https://example.com | 發布時間：2026-01 | 信度：[Media]
8. [8] 法規資訊 — 政府網站 | https://example.com | 發布時間：2025-12 | 信度：[Official]
9. [9] 衝突來源1 — 報告 | https://example.com | 信度：[Industry]
10. [10] 衝突來源2 — 評論 | https://example.com | 信度：[Media]
---

---
### Chunk 02
- chunk_id: 02
- keywords: [Mermaid, mermaid, flowchart, 使用訣竅, 先讀結論, 核心訊息應在, 秒內理解, 三層證據, 官方, 學術]
- scope: 正式報告模板_v2.0.md：正式報告模板_v2.0
- content_type: template
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/正式報告模板_v2.0.md
- sensitivity: medium
內容：
---

## 使用訣竅

1. **先讀結論**：核心訊息應在 5 秒內理解
2. **三層證據**：官方 + 學術 + 業界
3. **避免推測**：推測需標示「預期」或「假設」
4. **標記風險**：列出 1-2 個最大風險
5. **時間戳記**：標註資料時間更新程度

---

## Mermaid流程圖示意

```mermaid
flowchart TD
    A[準備數據] --> B[撰寫核心結論]
    B --> C[蒐集依據與引用]
    C --> D[衝突檢查]
    D --> E[風險與邊界標註]
    E --> F[完成正式報告]
```

#智研系統 #正式報告 #引用管理 #品質檢查
---

## 原文關鍵摘錄
- "# 正式報告模板_v2.0"
- "## 用途"
- "適用於撰寫[[正式報告]]，對象為老闆、客戶或主管。"
- "核心結構涵蓋：現況 / 趨勢 / 風險 / 建議 / 結論。"
- "---"
- "## 固定回答結構"
- "### 1) 核心結論"
