---
alias: []
tags: [ojAJz-_oc9QGxTnCh44sdmkdsjpUvHLRUklIc-cqIT4, nightlyJudgmentBatch, module_id, LIVE, spreadsheet_url, https, docs, google, com, spreadsheets]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip > 法務智研_FINAL_v1.8_規格強化包.zip > 法務智研_FINAL_v1.8_最小修補包.zip, 39_試算表智慧檢索_v1.4.json]
sensitivity: medium
---
# {
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [ojAJz-_oc9QGxTnCh44sdmkdsjpUvHLRUklIc-cqIT4, nightlyJudgmentBatch, module_id, LIVE, spreadsheet_url, https, docs, google, com, spreadsheets]
- scope: 39_試算表智慧檢索_v1.4.json：{
- content_type: knowledge
- source: 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip > 法務智研_FINAL_v1.8_規格強化包.zip > 法務智研_FINAL_v1.8_最小修補包.zip:39_試算表智慧檢索_v1.4.json
- sensitivity: medium
內容：
{
  "module_id": "39_試算表智慧檢索_v1.4_LIVE",
  "spreadsheet_url": "https://docs.google.com/spreadsheets/d/1ojAJz-_oc9QGxTnCh44sdmkdsjpUvHLRUklIc-cqIT4",
  "spreadsheet_id": "1ojAJz-_oc9QGxTnCh44sdmkdsjpUvHLRUklIc-cqIT4",
  "gas_functions": {
    "nightlyBatch": "nightlyJudgmentBatch()",
    "query": "queryJudgmentsByKeyword(keyword)"
  },
  "auto_trigger": "每日00:05執行nightlyJudgmentBatch",
  "query_usage": "我讀取試算表→Top3判例→即時引用",
  "total_control_link": "[file:106]",
  "status": "🟢已部署運行"
}
---

## 原文關鍵摘錄
- "{"
- ""module_id": "39_試算表智慧檢索_v1.4_LIVE","
- ""spreadsheet_url": "https://docs.google.com/spreadsheets/d/1ojAJz-_oc9QGxTnCh44sdmkdsjpUvHLRUklIc-cqIT4","
- ""spreadsheet_id": "1ojAJz-_oc9QGxTnCh44sdmkdsjpUvHLRUklIc-cqIT4","
- ""gas_functions": {"
- ""nightlyBatch": "nightlyJudgmentBatch()","
- ""query": "queryJudgmentsByKeyword(keyword)""
