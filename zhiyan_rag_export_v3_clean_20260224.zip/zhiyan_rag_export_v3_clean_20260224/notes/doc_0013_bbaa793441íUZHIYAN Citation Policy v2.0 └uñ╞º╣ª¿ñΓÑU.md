---
alias: []
tags: [https, example, com, 舊式, Report, Citation, Policy, MASTER, BOOT, Space]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/30_引用升級手冊_v2.0.md]
sensitivity: high
---
# ZHIYAN Citation Policy v2.0 優化完成手冊
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [舊式, URL, artifact_id, ZHIYAN, Citation, Policy, 位置, 何時用, Asia, Taipei]
- scope: 30_引用升級手冊_v2.0.md：ZHIYAN Citation Policy v2.0 優化完成手冊
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/30_引用升級手冊_v2.0.md
- sensitivity: high
內容：
# ZHIYAN Citation Policy v2.0 優化完成手冊

**完成日期：2026-01-16（Asia/Taipei）**
**適用範圍：Perplexity Pro Space — 智研 ZHIYAN 系統**
**狀態：Ready for Deployment**

---

## 優化概述

### 問題診斷
- **舊痛點**：每個回答都密集穿插 （舊式S1）（舊式S2）（舊式S3）…，導致訊息難讀、視覺干擾
- **例子**：
  ```
  這是第一個觀點（舊式S1），但也有人認為（舊式S2）。根據數據（舊式S3），趨勢是（舊式S4）。
  最後來源：（舊式S1） URL （舊式S2） URL （舊式S3） URL （舊式S4） URL
  ```

### 優化方向
- **改為**：段落內最小 inline 標記 [1][2]…，段落末尾聚類，全文末尾彙總表
- **效果**：訊息流暢、易掃讀、專業感提升

---

## 三個新版本檔案

### 1️⃣ 05_CITATION_POLICY_v2.0（核心政策）[41]
**位置**：artifact_id:41
**內容**：
- C1. 引用策略（段落內 [1][2]… vs 末尾表）
- C2. 來源標記格式（統一規範）
- C3. 全文末尾清單（彙總表）
- C4. 三個 MODE 適配規則（QC / RESEARCH / REPORT）
- C5. 特殊情況（上傳檔案、Google Drive、版本衝突）
- C6. 衝突檢查標準（如何標註矛盾來源）
- C7. 品質檢查清單（自檢表）
- C8. 常見問題與範例

**何時用**：
- 作為「引用規範」的唯一真理版本
- 新人或每次疑惑時查閱

### 2️⃣ 02_MASTER_v2.0.0（主人格）[42]
**位置**：artifact_id:42
**內容**：
- 版本更新日誌（v1.1.0 → v2.0.0 變更紀錄）
- 角色任務說明（整理回報、不推理、不新增事實）
- 人格鎖定與漂移定義
- 語氣與表達（特助型、例外切換為正式）
- 允許行為表（包含「引用管理 NEW v2.0」）
- 禁止行為（加入「使用密集 （舊式S1）（舊式S2）…」禁止項）
- 違規範例（新增引用格式違規）
- **固定輸出骨架**（段落末尾聚類新格式）
- Citation Policy v2.0 內化規則（CP_001 ~ CP_004）
- 快速檢查清單

**何時用**：
- 我（AI）執行回答時自動套用
- 核對我是否遵守「主人格」規則

### 3️⃣ 03_BOOT_v2.40（路由）[43]
**位置**：artifact_id:43
**內容**：
- 版本更新（v2.39 → v2.40 變更表）
- 相依檔案清單（哪些檔案一起更新）
- 載入鐵律（硬性規則）
- 模式選單（L1 人格、L2 模組）
- 入口判斷（何時觸發各模式）
- 輸出格式提醒（舊版禁用 vs 新版必用）
- 引用政策適配表（各 Mode 的規則）
- 版本兼容性聲明
- 實施時間表（何時起啟用）
- 快速故障排查

**何時用**：
- 我（AI）在路由時自動套用
- 核對我是否遵守「啟用流程」

---

## 使用流程

### 你的視角（簡化版）
---

---
### Chunk 02
- chunk_id: 02
- keywords: [https, example, com, 舊式, Report, Industry, Data, Methodology, 信度, McKinsey]
- scope: 30_引用升級手冊_v2.0.md：ZHIYAN Citation Policy v2.0 優化完成手冊
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/30_引用升級手冊_v2.0.md
- sensitivity: high
內容：
```
你的問題
  ↓
[舊版] → 我回答 → 密集 （舊式S1）（舊式S2）… → 訊息干擾 ❌
  ↓
[新版 v2.0] → 我回答 → [1][2]… + 末尾表 → 訊息清爽 ✓
  ↓
你複製改稿到檔案 → 貼回 Drive
```

### 我（AI）的視角（技術版）

```
L0.5 SRP 分級（安全檢查）
  ↓
L0 CORE_GATE（事實驗證）
  ↓
L0 階段 2 QC（交叉檢查）
  ↓
L1 人格層
  ├─ MASTER v2.0.0（內化 Citation Policy v2.0）
  ├─ CONSULTANT / TUTOR / WRITER / TA（自動套用 v2.0）
  └─ LEGAL_WRITER（自動套用 v2.0）
  ↓
L2 模組層
  ├─ CONTRACT_RISK（自動套用 v2.0）
  └─ LITIGATION（自動套用 v2.0）
  ↓
輸出格式檢查（BOOT v2.40 驗證）
  ├─ Inline 標記 [1][2]…？ ✓
  ├─ 段落末尾【本段資料來源】？ ✓
  ├─ 全文末尾彙總表？ ✓
  └─ 無舊版 （舊式S1）（舊式S2）…？ ✓
  ↓
交付
```

---

## 變更對照表（新舊格式）

### 舊版格式（v1.0）— 禁用

```
1) 核心結論
目前產品市占率為 23%（舊式S1），預期今年成長到 28%（舊式S2）。

2) 依據
根據調查報告（舊式S3），消費者滿意度提升（舊式S4），推動購買意願（舊式S5）。

3) 衝突檢查
來源 A 和來源 B 對數字有出入（舊式S6）。

4) 風險與邊界
資料庫更新時間為 2026-01-15（舊式S7）。

5) 來源
（舊式S1） McKinsey 2026 Market Report — https://example.com
（舊式S2） Industry Forecast 2026 — https://example.com
（舊式S3） Consumer Survey 2026 — https://example.com
（舊式S4） Brand Perception Study — https://example.com
（舊式S5） Purchase Intent Analysis — https://example.com
（舊式S6） Data Methodology Comparison — https://example.com
（舊式S7） Database Update Log — https://example.com
```

### 新版格式（v2.0）— 必用

```
1) 核心結論
目前產品市占率為 23%[1]，預期今年成長到 28%[2]。

【本段資料來源】
[1] McKinsey 2026 Market Report — https://example.com
[2] Industry Forecast 2026 — https://example.com

2) 依據
根據調查報告[3]，消費者滿意度提升，推動購買意願[4]。

【本段資料來源】
[3] Consumer Survey 2026 — https://example.com
[4] Brand Perception Study — https://example.com

3) 衝突檢查
來源 A[5] 和來源 B[6] 對數字有出入，差異原因為定義範圍不同。

【本段資料來源】
[5] Data Methodology Report A — https://example.com
[6] Data Methodology Report B — https://example.com

4) 風險與邊界
資料庫更新時間為 2026-01-15[7]。

【本段資料來源】
[7] Database Update Log — https://example.com

---

【完整資料來源清單】
[1] McKinsey 2026 Market Report — 媒體 | https://example.com | 信度：[Industry]
[2] Industry Forecast 2026 — 機構 | https://example.com | 信度：[Official]
[3] Consumer Survey 2026 — 研究 | https://example.com | 信度：[Academic]
[4] Brand Perception Study — 公司 | https://example.com | 信度：[Industry]
[5] Data Methodology Report A — 新聞 | https://example.com | 信度：[Media]
[6] Data Methodology Report B — 新聞 | https://example.com | 信度：[Media]
[7] Database Update Log — 平台 | https://example.com | 信度：[Official]
```
---

---
### Chunk 03
- chunk_id: 03
- keywords: [BOOT, Space, 舊式, 完成, 的內容替換, Inline, CITATION_POLICY, MASTER, Citation, Policy]
- scope: 30_引用升級手冊_v2.0.md：ZHIYAN Citation Policy v2.0 優化完成手冊
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/30_引用升級手冊_v2.0.md
- sensitivity: high
內容：
### 差異對比

| 面向 | v1.0 | v2.0 |
|------|------|------|
| Inline 密度 | 每句一個 （舊式S#） | 第一次提及才加 [#] |
| 來源聚集 | 全部末尾堆在一起 | 分段末尾表 + 全文彙總 |
| 視覺干擾 | 高（看起來很混亂） | 低（訊息清爽） |
| 查閱易度 | 低（要反覆找 （舊式S#）） | 高（對應段落清楚） |
| 專業度 | 中等 | 高（同學術論文） |

---

## 實施計畫

### 時程

| 日期 | 工作項 | 完成度 |
|------|--------|--------|
| 2026-01-16 | 產出 v2.0 三新檔 | ✓ 完成 |
| 2026-01-16 | BOOT v2.40 指向新版 | ✓ 完成 |
| 2026-01-16 | 此手冊編寫 | ✓ 完成 |
| 2026-01-17 | 正式啟用 v2.0（所有新回答自動套用） | ⏳ 待啟用 |
| 2026-01-17 ~ 02-01 | 過渡期（舊格式自動轉換 + 警告） | ⏳ 待執行 |
| 2026-02-02 | 舊格式停止自動轉換，直接違規中止 | ⏳ 待執行 |

### 你需要做的

**必做（立即）：**
1. ✓ 確認三個新檔案已產出 [41][42][43]
2. ⏳ 將三個檔案複製貼到 Space（更新舊版 05_CITATION_POLICY, 02_MASTER, 03_BOOT）

**選做（參考）：**
3. 📖 讀一遍 [41]（Citation Policy v2.0）理解新規則
4. 📖 讀一遍本手冊，掌握變更概况

**無需做：**
- 手動改舊回答的引用格式（我會在新回答自動套用 v2.0）

---

## 常見問題（FAQ）

### Q1. 為什麼要改引用格式？
A. 密集 （舊式S1）（舊式S2）… 造成訊息難讀，你曾說「很干擾」。新格式改善了這點。

### Q2. 會不會漏掉來源？
A. 不會。每個引用都編號 [1][2][3]…，對應末尾表。反而更清楚。

### Q3. 舊回答的引用格式要改嗎？
A. 不用。只影響新回答（2026-01-17 起）。

### Q4. 能混用新舊格式嗎？
A. 不行。v2.40 BOOT 會檢查，混用會觸發「輕微違規警告」。

### Q5. 如果遇到過渡期（01-17 ~ 02-01）的舊格式回答怎辦？
A. 系統會自動轉換為新格式，並輸出警告。2026-02-02 後不再轉換。

### Q6. 三個新檔案要貼在哪？
A. 更新你 Space 內的舊檔：
- 05_CITATION_POLICY_v1.0 → 用 05_CITATION_POLICY_v2.0 的內容替換
- 02_MASTER_v1.1.0 → 用 02_MASTER_v2.0.0 的內容替換
- 03_BOOT_v2.39 → 用 03_BOOT_v2.40 的內容替換

### Q7. 改完檔案要通知你嗎？
A. 不用。我會自動讀取最新版本（Google Drive Connector 同步）。

### Q8. 這對我的工作流有什麼好處？
A. **改善：**
- 訊息更流暢、易掃讀 → 節省理解時間
- 段落末尾聚類 → 快速找到該段引用
- 全文彙總表 → 一眼看完所有來源
- 專業風格 → 若要交付客戶更有說服力

---

## 技術詞彙對照表
---

---
### Chunk 04
- chunk_id: 04
- keywords: [MASTER, Citation, Policy, BOOT, table, Space, 舊式, inline, citation, aggregation]
- scope: 30_引用升級手冊_v2.0.md：ZHIYAN Citation Policy v2.0 優化完成手冊
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/30_引用升級手冊_v2.0.md
- sensitivity: high
內容：
| 術語 | 說明 |
|------|------|
| Citation Policy v1.0 | 舊引用規範（密集 （舊式S1）（舊式S2）…） |
| Citation Policy v2.0 | 新引用規範（優化 [1][2]… + 末尾表） |
| MASTER v1.1.0 | 舊主人格（使用 v1.0 政策） |
| MASTER v2.0.0 | 新主人格（內化 v2.0 政策） |
| BOOT v2.39 | 舊路由器（指向 MASTER v1.1.0） |
| BOOT v2.40 | 新路由器（指向 MASTER v2.0.0） |
| inline citation | 文中穿插的引用標記（如 [1]） |
| aggregation table | 末尾聚集表（【本段資料來源】） |
| summary table | 全文彙總表（【完整資料來源清單】） |

---

## 後續迭代（未來規劃）

### 考慮中（v2.1 候選）
- [ ] 多語言引用格式（日文、韓文、西班牙文）
- [ ] 自動生成 BibTeX / APA / Chicago 格式轉換
- [ ] 引用信度分級的視覺化（顏色編碼）
- [ ] 衝突來源的自動標註與警告

### 不在計劃內
- ✗ 回到舊版 （舊式S1）（舊式S2）… 格式（已優化，無回頭）
- ✗ 超連結直接內嵌文中（會降低易讀性）
- ✗ 自動修改 Google Drive 檔案（無寫權限）

---

## 聯絡 & 反饋

若對新版本有疑問或建議：
1. 在 Space 開新 thread，標題「v2.0 引用政策反饋」
2. 貼上具體問題 / 建議
3. 我會立即回應並調整（若需要）

---

**版本控制**
- 手冊版本：v1.0（2026-01-16）
- 適用系統：ZHIYAN v2.40+
- 檔案位置：
  - [41] 05_CITATION_POLICY_v2.0.md
  - [42] 02_MASTER_v2.0.0.md
  - [43] 03_BOOT_v2.40.md
  - [此文] 04_CITATION_UPGRADE_HANDBOOK.md

---

**完成！接下來請複製三個新檔案到你的 Space，就完全啟用新引用政策了。** ✨
---

## 原文關鍵摘錄
- "# ZHIYAN Citation Policy v2.0 優化完成手冊"
- "**完成日期：2026-01-16（Asia/Taipei）**"
- "**適用範圍：Perplexity Pro Space — 智研 ZHIYAN 系統**"
- "**狀態：Ready for Deployment**"
- "---"
- "## 優化概述"
- "### 問題診斷"
