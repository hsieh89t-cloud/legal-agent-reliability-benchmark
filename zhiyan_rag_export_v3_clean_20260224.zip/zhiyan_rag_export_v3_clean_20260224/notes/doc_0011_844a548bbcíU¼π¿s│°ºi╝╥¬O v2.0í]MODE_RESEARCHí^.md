---
alias: []
tags: [https, example, com, 信度, Official, Academic, 本段資料來源, Media, URL, IPCC]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/21_模式_RESEARCH_研究_v2.0.md]
sensitivity: medium
---
# 研究報告模板 v2.0（MODE_RESEARCH）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [https, example, com, 信度, Official, 來源, Academic, Media, Industry, 媒體]
- scope: 21_模式_RESEARCH_研究_v2.0.md：研究報告模板 v2.0（MODE_RESEARCH）
- content_type: template
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/21_模式_RESEARCH_研究_v2.0.md
- sensitivity: medium
內容：
# 研究報告模板 v2.0（MODE_RESEARCH）

**版本**：v2.0（新引用格式）
**日期**：2026-01-16
**適用**：查詢資料、整理多個來源、交叉比對、做研究總結

---

## 用途

當你需要「**查資料、整理多個來源、交叉比對、寫研究報告**」時，用這個模板。

我會按照以下五個區塊回答，按「官方 → 學術 → 媒體」三層分層列出依據。

---

## 固定回答結構

### 1) 核心結論

**一句話總結**：研究發現的最可信版本是什麼？有沒有不確定性？

【本段資料來源】
[1] 最主要的研究來源 — URL / 位置

---

### 2) 依據

**分層列出依據**（重要性 + 可信度由高到低）：

#### 🏛️ 官方數據 / 一手資料
- [2] 來源 A：說了什麼
- [3] 來源 B：說了什麼

#### 📚 學術研究 / 專業報告
- [4] 來源 C：研究發現
- [5] 來源 D：理論依據

#### 📰 媒體報導 / 業界評論
- [6] 來源 E：最新動態
- [7] 來源 F：專家看法

【本段資料來源】
[2] 官方來源 — 政府 / 機構 | https://example.com | 信度：[Official]
[3] 官方來源 — 統計機構 | https://example.com | 信度：[Official]
[4] 學術研究 — 期刊名 | https://example.com | 信度：[Academic]
[5] 學術研究 — 研究報告 | https://example.com | 信度：[Academic]
[6] 媒體報導 — 新聞媒體 | https://example.com | 信度：[Media]
[7] 專家評論 — 產業分析 | https://example.com | 信度：[Industry]

---

### 3) 衝突檢查

**檢查不同來源的版本差異**：

- 結論：檢出衝突 / 未檢出衝突
- 檢查範圍：比對了哪些來源
- 衝突點（如有）：來源 A 說 X，來源 B 說 Y，差異原因可能是…
- 目前較可信版本：根據最新官方數據，應採用…

【本段資料來源】
[8] 衝突來源 1 — https://example.com
[9] 衝突來源 2 — https://example.com

---

### 4) 風險與邊界

**預設 1-2 點提醒**（不要超過 3 點）：

- ⚠️ 資料更新時間：2026-01-15（若更新則結論可能改變）
- ⚠️ 定義差異：不同機構對「市占率」的定義可能不同

【本段資料來源】
（若此段無新引用，可省略）

---

### 5) 完整資料來源清單

（彙總表）

[1] 最主要研究 — 機構名 | https://example.com | 更新：2026-01-15 | 信度：[Official]
[2] 官方數據 — 政府機構 | https://example.com | 信度：[Official]
[3] 官方統計 — 統計局 | https://example.com | 信度：[Official]
[4] 學術論文 — 期刊名 | https://example.com | 信度：[Academic]
[5] 研究報告 — 研究所 | https://example.com | 信度：[Academic]
[6] 新聞報導 — 媒體名 | https://example.com | 信度：[Media]
[7] 產業分析 — 分析機構 | https://example.com | 信度：[Industry]
[8] 衝突來源 A — 媒體 | https://example.com | 信度：[Media]
[9] 衝突來源 B — 媒體 | https://example.com | 信度：[Media]
---

---
### Chunk 02
- chunk_id: 02
- keywords: [https, example, com, Official, 信度, IPCC, Academic, NASA, NOAA, 本段資料來源]
- scope: 21_模式_RESEARCH_研究_v2.0.md：研究報告模板 v2.0（MODE_RESEARCH）
- content_type: template
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/21_模式_RESEARCH_研究_v2.0.md
- sensitivity: medium
內容：
---

## 快速填空範例

### 例 1：簡單的研究報告

```
1) 核心結論
全球 AI 採用率在 2025 年達到 71%[1]，較 2024 年增長 12%。
預期 2026 年將突破 80%[2]。

【本段資料來源】
[1] 全球 AI 採用調查 2025 — https://example.com
[2] 業界預測報告 — https://example.com

2) 依據

🏛️ 官方數據
- [3] Gartner 企業調查：71% 企業已實施 AI[3]
- [4] IDC 市場報告：2025 年 AI 市場規模 5000 億美元[4]

📚 學術研究
- [5] Stanford AI Index 2025：全球 AI 投資集中在北美、亞洲[5]
- [6] MIT 研究：AI 技能缺口達 50 萬人[6]

📰 媒體報導
- [7] TechCrunch：OpenAI 新模型引發業界討論[7]
- [8] McKinsey：企業 AI 戰略面臨三大挑戰[8]

【本段資料來源】
[3] Gartner 調查 — https://example.com | 信度：[Official]
[4] IDC 報告 — https://example.com | 信度：[Official]
[5] Stanford AI Index — https://example.com | 信度：[Academic]
[6] MIT 研究 — https://example.com | 信度：[Academic]
[7] TechCrunch — https://example.com | 信度：[Media]
[8] McKinsey 分析 — https://example.com | 信度：[Industry]

3) 衝突檢查
結論：未檢出重大衝突
檢查範圍：全球 AI 採用率數據（2024-2025）
口徑統一性：各機構定義類似（已實施 AI = 至少投入一項 AI 技術）[9]

【本段資料來源】
[9] 定義對標 — https://example.com

...以此類推
```

### 例 2：有衝突的研究

```
1) 核心結論
全球氣溫上升速度存在測量分歧[1]。
過去 10 年上升 0.18°C（範圍 0.13-0.23°C，95% 信賴區間）[1]。

【本段資料來源】
[1] IPCC 第六次評估報告 — https://example.com

2) 依據

🏛️ 官方數據
- [2] NASA GISS：過去 10 年上升 0.20°C[2]
- [3] NOAA：過去 10 年上升 0.18°C[3]

📚 學術研究
- [4] Berkeley Earth：過去 10 年上升 0.19°C[4]
- [5] 日本氣象廳：過去 10 年上升 0.17°C[5]

【本段資料來源】
[2] NASA GISS — https://example.com | 信度：[Official]
[3] NOAA — https://example.com | 信度：[Official]
[4] Berkeley Earth — https://example.com | 信度：[Academic]
[5] 日本氣象廳 — https://example.com | 信度：[Official]

3) 衝突檢查
結論：檢出衝突（但在合理範圍內）
檢查範圍：全球平均氣溫上升速度

分歧點：
- NASA 報 0.20°C，NOAA 報 0.18°C，差異 0.02°C
- 原因：測量方法略異（衛星 vs 地表測站權重不同）

目前較可信版本：
採用 IPCC 官方綜合結論：**0.18°C ± 0.05°C**[6]
原因：IPCC 綜合了多個獨立機構的數據，信度最高[6]

【本段資料來源】
[6] IPCC 合併方法論 — https://example.com

...以此類推
```

---

## 新舊格式對比

### ❌ 舊格式（禁用）
```
根據調查[1]，官方數據[2]，和媒體報導[3]…
---

---
### Chunk 03
- chunk_id: 03
- keywords: [https, example, com, URL, Citation, Policy, MODE_RESEARCH_, txt, deprecated, 本段資料來源]
- scope: 21_模式_RESEARCH_研究_v2.0.md：研究報告模板 v2.0（MODE_RESEARCH）
- content_type: template
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/21_模式_RESEARCH_研究_v2.0.md
- sensitivity: medium
內容：
【來源】
[1] URL
[2] URL
[3] URL
```

### ✅ 新格式（使用中）
```
根據調查[1]，官方數據顯示[2]…
不過媒體有不同看法[3]…

【本段資料來源】
[1] 調查報告 — https://example.com
[2] 官方數據 — https://example.com
[3] 媒體報導 — https://example.com

總結來看[4]…

【本段資料來源】
[4] 綜合分析 — https://example.com
```

---

## 使用訣竅

1. **分層很重要**：官方 > 學術 > 媒體（按信度排列）
2. **交叉驗證**：同一事實用 2-3 個獨立來源驗證
3. **明確衝突**：有不同版本時，明確說明原因
4. **標記時間**：資料是 2026-01-15 的，會影響結論的新鮮度
5. **彙總表清楚**：全文末尾一定要有【完整資料來源清單】

---

## 檔案版本

- 範本版本：v2.0（2026-01-16）
- 適用政策：Citation Policy v2.0（新引用格式）
- 舊版本：03_MODE_RESEARCH_模板.txt（已棄用，移至 /deprecated）
---

## 原文關鍵摘錄
- "# 研究報告模板 v2.0（MODE_RESEARCH）"
- "**版本**：v2.0（新引用格式）"
- "**日期**：2026-01-16"
- "**適用**：查詢資料、整理多個來源、交叉比對、做研究總結"
- "---"
- "## 用途"
- "當你需要「**查資料、整理多個來源、交叉比對、寫研究報告**」時，用這個模板。"
