---
alias: []
tags: [open-note, bear, x-callback-url, persona, Persona, law, Module, module, GPT, 同上]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/00_索引｜育昇智研維護入口.md]
sensitivity: medium
---
# | 索引ID          | 類別        | 名稱（唯一主檔）                   | Bear 連結（open-note?id=
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [open-note, bear, x-callback-url, persona, Persona, law, Module, module, GPT, 同上]
- scope: 00_索引｜育昇智研維護入口.md：| 索引ID          | 類別        | 名稱（唯一主檔）                   | Bear 連結（open-note?id=
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/00_索引｜育昇智研維護入口.md
- sensitivity: medium
內容：
| 索引ID          | 類別        | 名稱（唯一主檔）                   | Bear 連結（open-note?id=）                 | Tag 建議            | 捷徑用途（給 GPT）      | 備註        |
| ------------- | --------- | -------------------------- | -------------------------------------- | ----------------- | ---------------- | --------- |
| P-CORE        | Persona   | 阿研核心人格（常駐）                 | bear://x-callback-url/open-note?id=（填） | #persona/core     | 定位核心 persona 直接改 | 只放「不可變原則」 |
| P-LAW-1       | Persona   | 控方律師人格                     | bear://x-callback-url/open-note?id=（填） | #persona/law      | 直接改語氣模組          | 對照表參考文件   |
| P-LAW-2       | Persona   | 辯方律師人格                     | bear://x-callback-url/open-note?id=（填） | #persona/law      | 同上               |           |
| P-LAW-3       | Persona   | 檢察官人格                      | bear://x-callback-url/open-note?id=（填） | #persona/law      | 同上               |           |
| P-LAW-4       | Persona   | 法務諮詢人格                     | bear://x-callback-url/open-note?id=（填） | #persona/law      | 同上               |           |
| M-CMD         | Module    | 中文指令模組（切換/鎖）               | bear://x-callback-url/open-note?id=（填） | #module/command   | 捷徑要引用的指令表        |           |
| M-HI          | Module    | Honest Inference Layer     | bear://x-callback-url/open-note?id=（填） | #module/qc        | 低信心標註規則          |           |
| M-QC          | Module    | QC 檢核清單（十項）                | bear://x-callback-url/open-note?id=（填） | #module/qc        | 產出前自檢            |           |
| SYS-BOOT      | System    | Boot / Router / Session 規格 | bear://x-callback-url/open-note?id=（填） | #system/router    | 需要改路由時用          |           |
| SYS-CHANGELOG | System    | 變更紀錄（全域）                   | bear://x-callback-url/open-note?id=（填） | #system/changelog | GPT 回報時附上        | 一律追加不新建   |
| REF-ARCH      | Reference | 參考文件區（外部來源/附件）             | bear://x-callback-url/open-note?id=（填） | #ref              | 需要對照時用           | 只放引用與連結   |
---

## 原文關鍵摘錄
- "| 索引ID          | 類別        | 名稱（唯一主檔）                   | Bear 連結（open-note?id=）                 | Tag 建議            | 捷徑用途（給 GPT）      | 備註        |"
- "| ------------- | --------- | -------------------------- | -------------------------------------- | ----------------- | ---------------- | --------- |"
- "| P-CORE        | Persona   | 阿研核心人格（常駐）                 | bear://x-callback-url/open-note?id=（填） | #persona/core     | 定位核心 persona 直接改 | 只放「不可變原則」 |"
- "| P-LAW-1       | Persona   | 控方律師人格                     | bear://x-callback-url/open-note?id=（填） | #persona/law      | 直接改語氣模組          | 對照表參考文件   |"
- "| P-LAW-2       | Persona   | 辯方律師人格                     | bear://x-callback-url/open-note?id=（填） | #persona/law      | 同上               |           |"
- "| P-LAW-3       | Persona   | 檢察官人格                      | bear://x-callback-url/open-note?id=（填） | #persona/law      | 同上               |           |"
- "| P-LAW-4       | Persona   | 法務諮詢人格                     | bear://x-callback-url/open-note?id=（填） | #persona/law      | 同上               |           |"
