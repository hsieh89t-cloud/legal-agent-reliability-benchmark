---
alias: []
tags: [Space_, txt, 上傳到, audit_, reference_, 人格, 稽核, README, HYBRID, 建議與禁忌]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/上傳檔案清單_建議與禁忌.md]
sensitivity: high
---
# 上傳檔案清單_建議與禁忌
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [上傳檔案清單, 建議與禁忌, 核心目的, 提供完整的, 使用建議, 方便在智研系, 統中進行版本, 審計與部署, 檔案目錄總覽]
- scope: 上傳檔案清單_建議與禁忌.md：上傳檔案清單_建議與禁忌
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/上傳檔案清單_建議與禁忌.md
- sensitivity: high
內容：
# 上傳檔案清單_建議與禁忌

## 核心目的
提供完整的[[檔案清單]]與[[使用建議]]，方便在智研系統中進行版本管理、審計與部署。

## 檔案目錄總覽
---

---
### Chunk 02
- chunk_id: 02
- keywords: [Space_, txt, 上傳到, 人格, HYBRID, README_, 模組, SHA256, baf658c0942797ed2802a71f2fe8eef0e6dd7c2f4d29d41d5cc8bad64aeb73f, e5011298a035606a469c500b61bfb5be13643d353046d0dbc240971023135190]
- scope: 上傳檔案清單_建議與禁忌.md：上傳檔案清單_建議與禁忌
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/上傳檔案清單_建議與禁忌.md
- sensitivity: high
內容：
| SHA256 | 目錄路徑 | 檔名 |
|--------|---------|------|
| 5baf658c0942797ed2802a71f2fe8eef0e6dd7c2f4d29d41d5cc8bad64aeb73f | 00_貼到Space_指令 | 01_智研空間指令_貼到Space_v3.
00.
txt |
| e5011298a035606a469c500b61bfb5be13643d353046d0dbc240971023135190 | 01_上傳到Space_檔案 | 00_使用說明_README.
txt |
| 27f10c31f5bcd8b67b2e6dc833ca7a4428bb2b1b2c68eb8da2da73abf6a4c402 | 01_上傳到Space_檔案 | 00_混合部署指南_HYBRID.
md |
| 11a016f4e51682097a5ba33e285014b40644212a88c985bb1aa6e0b9a8634f08 | 01_上傳到Space_檔案 | 00_開始閱讀_入口導覽_v2.
1.
md |
| 5a26ceffa51f8f01d97985ea539d054e6b6b081156ab679012c7d9b7af4b817e | 01_上傳到Space_檔案 | 01_智研空間_核心規格_v3.
00_HYBRID.
md |
| d5f706c615057e00d867f353924df0b209273b611eb77730a3857d8d7bc5ca3d | 01_上傳到Space_檔案 | 01_核心閘門_ZHIYAN_CORE_GATE.
txt |
| 0ae82ef9298aeb61c8672e386b4c1cba0ac79d908184e018cc7b087ce574a7ac | 01_上傳到Space_檔案 | 02_載入索引_INDEX__ZHIYAN_PACK.
txt |
| 937ae74febb18d11b1a9aff0e60dc9f73b737fce20570aaf9c9e0048982c7026 | 01_上傳到Space_檔案 | 03_README_總覽.
md |
| b29b8b2737701acc28f0438b6cfa409f474ff5fe5d3482fb285bda780b728626 | 01_上傳到Space_檔案 | 04_README_極簡.
md |
| 8b88935d8ec4d1f4e40feec29297e37d1bb32450b1d1656e236a2da01d455a2b | 01_上傳到Space_檔案 | 10_主人格_MASTER_v2.
0.
0.
md |
| fad80805ff8e3873ff3db1cb4b652a915e563585d9b12b1a7eb3b27cf8a000b8 | 01_上傳到Space_檔案 | 11_啟動流程_BOOT_v2.
40.
md |
| d396e05a2456431fdc431c25039023d1adb7fd2e86256710b27632b330e0a2f7 | 01_上傳到Space_檔案 | 20_模式_REPORT_報告_v2.
0.
md |
| 844a548bbc38a2ffe55abb1bcc7daf7ffa7a8bf61247f24cc9e94d4d08c2df58 | 01_上傳到Space_檔案 | 21_模式_RESEARCH_研究_v2.
0.
md |
| 12e24f532b44a8acaee8bb8393e1bbaa2b5b3962e60b4aa696f69759f4181392 | 01_上傳到Space_檔案 | 22_模式_QC_查核_v2.
0.
md |
| 11a80675b9d8e0f819546d8ca3cd7394df88f678ad9bc710bed36b5e1cb49410 | 01_上傳到Space_檔案 | 31_引用政策_CITATION_POLICY_v2.
0.
md |
| 7a9442464e9271bea08ad54849b9fa7dff1fb1daf678ae9128d0cfa07e1a3471 | 01_上傳到Space_檔案 | 40_人格_助教批改_TA.
txt |
| f7180c5bca0a99ba376cb3e324d87dd9d6910133ef17c1f60e148eb3e940fe29 | 01_上傳到Space_檔案 | 41_人格_文書_LEGAL_WRITER.
txt |
| eedb32ef2b82619738099a7de6687da3c622bc84d24e38ef5cb42c5786e2c67a | 01_上傳到Space_檔案 | 42_人格_申論寫作_WRITER.
txt |
| 14ec1a132924f2ca38df9c315c20a4a2ebcef6321c0ed797da28041839eee3b3 | 01_上傳到Space_檔案 | 43_人格_顧問_CONSULTANT.
txt |
| 6d112b65afcd942a7bbbf50dd3fe116c6b2e2eb9282610d647267b8d185d8b1f | 01_上傳到Space_檔案 | 44_人格_教學_TUTOR.
txt |
| 34ecbfc89dceaa0cef60a0f2983bdaa85f67b5dd6b533bc99efc587dc22b6376 | 01_上傳到Space_檔案 | 50_模組_訴訟五維推演_LITIGATION.
txt |
| 15d93693f33690dbcadb5ef4fd50d6bc945b5ab235faafe69438c131c4f54153 | 01_上傳到Space_檔案 | 51_模組_安全風險對話處理_SRP_v1.
0.
txt |
| 06bb60563e55e989e5796741d2b11023b928268bf8b2580f89d0a342bfa85296 | 01_上傳到Space_檔案 | 52_模組_合約風險策略_CONTRACT_RISK.
txt |
| 48034f85c1f7488fa3069e06a7f46d9e56e06916c71d071b2c2bdccb7e1a554e | 01_上傳到Space_檔案 | 90_上傳檔案清單_建議與禁忌.
txt |
| 85efb25d977513a3be360541467c4270b99e092ee61a6d0e0e4e8476e48dadf9 | 01_上傳到Space_檔案 | 95_版本更新紀錄_RELEASE_NOTES.
md |
| e0ee428416723d54af89b18fab1b46ec33145fea54d1df7edd45a19f2280ce56 | 01_上傳到Space_檔案 | 96_權限矩陣_PERMISSION_MATRIX.
md |
| 03a3de7c050a0af64c4ca3ec68a157e7451fbb09667e5d9d5144330396d997e6 | 98_audit_稽核
---

---
### Chunk 03
- chunk_id: 03
- keywords: [audit_, txt, reference_, Space_, 稽核, 勿載入, GDrive_manifest, json, c4b99552880f477e9a90cbc85df0f9fd7e4a51bbfb8a3e25615da47ac25e8087, TREE_]
- scope: 上傳檔案清單_建議與禁忌.md：上傳檔案清單_建議與禁忌
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/上傳檔案清單_建議與禁忌.md
- sensitivity: high
內容：
| GDrive_manifest.

json |
| c4b99552880f477e9a90cbc85df0f9fd7e4a51bbfb8a3e25615da47ac25e8087 | 98_audit_稽核 | TREE_結構地圖.
txt |
| a603157d8017122983bed5059a10f39ca71020af3ddbb41bae089178cce089a5 | 98_audit_稽核 | 移轉指南_v2.
39.
2_to_v3.
00.
3.
md |
| a0d8681862dd00762ec64a992d7cc700b62e0e0cd86b84f0f1ed4788faf3bb2e | 98_audit_稽核 | 總稽核報告.
txt |
| bbaa793441cca81020426aef3c16afac26c81dca50c31a4477b33bcf33400b63 | 99_reference_勿載入 | 30_引用升級手冊_v2.
0.
md |
| .
.
.
| .
.
.
| .
.
.
|

> 註：`99_reference_勿載入` 內檔案為歷史或備查用，不建議載入核心系統。

## 檔案分類與用途

### 1️⃣ 核心指令與入口
- 00_貼到Space_指令：提供[[系統貼上指令]]
- 01_上傳到Space_檔案/00_使用說明_README.txt：操作總覽
- 入口導覽與混合部署指南：協助初次導入

### 2️⃣ 系統配置與模組
- 核心規格、核心閘門、載入索引
- 模式文件（REPORT/RESEARCH/QC）
- 人格模組（TA、Writer、Consultant、Tutor）
- 功能模組（安全風險、合約風險、訴訟推演）

### 3️⃣ 審計與版本控管
- 版本更新紀錄、權限矩陣、稽核報告
- TREE結構地圖與GDrive Manifest

### 4️⃣ 歷史與備查檔
- `99_reference_勿載入` 內為過往版本與附件
- 僅供比對及[[稽核]]使用

## 建議與禁忌

| 建議 | 禁忌 |
|------|------|
| 保持檔名與版本一致 | 修改原始檔名 |
| 只載入現用檔案 | 將歷史檔載入核心 |
| 每次更新附帶版本紀錄 | 直接覆蓋無紀錄 |
| 定期稽核權限矩陣 | 忽略權限異動 |

## Mermaid流程圖（檔案處理流程）

```mermaid
flowchart TD
    A[上傳檔案] --> B{分類}
    B -->|現用| C[載入Space]
    B -->|歷史備查| D[歸檔勿載入]
    C --> E[更新版本紀錄]
    D --> F[審計參考用]
```

#智研系統 #版本控管 #檔案稽核 #資料管理
---

## 原文關鍵摘錄
- "# 上傳檔案清單_建議與禁忌"
- "## 核心目的"
- "提供完整的[[檔案清單]]與[[使用建議]]，方便在智研系統中進行版本管理、審計與部署。"
- "## 檔案目錄總覽"
- "| SHA256 | 目錄路徑 | 檔名 |"
- "|--------|---------|------|"
- "| 5baf658c0942797ed2802a71f2fe8eef0e6dd7c2f4d29d41d5cc8bad64aeb73f | 00_貼到Space_指令 | 01_智研空間指令_貼到Space_v3.00.txt |"
