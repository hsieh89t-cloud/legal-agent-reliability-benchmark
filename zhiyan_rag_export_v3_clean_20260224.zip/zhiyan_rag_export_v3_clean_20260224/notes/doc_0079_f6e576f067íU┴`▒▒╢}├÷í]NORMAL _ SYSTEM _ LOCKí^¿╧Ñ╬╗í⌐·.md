---
alias: []
tags: [NORMAL, Xing, LOCK, 育昇總務課, 總控開關, 使用說明, 目的, 避免誤觸工作, 此為, 防呆規則]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip, 智研x法言_最終整合包_v1.9.3/00_總覽與索引/GLOBAL_MODE_總控開關使用說明.md]
sensitivity: medium
---
# 總控開關（NORMAL / SYSTEM / LOCK）使用說明
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [NORMAL, Xing, LOCK, 育昇總務課, 總控開關, 使用說明, 目的, 避免誤觸工作, 此為, 防呆規則]
- scope: GLOBAL_MODE_總控開關使用說明.md：總控開關（NORMAL / SYSTEM / LOCK）使用說明
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 鏅虹爺x娉曡█v1.9.5.zip:智研x法言_最終整合包_v1.9.3/00_總覽與索引/GLOBAL_MODE_總控開關使用說明.md
- sensitivity: medium
內容：
# 總控開關（NORMAL / SYSTEM / LOCK）使用說明

目的：避免誤觸工作流。此為「防呆規則」，不屬真正安全驗證。

## 三種模式
- NORMAL：一般聊天（預設）。不跑任務入口、不做正式交付。
- SYSTEM：系統工作流。允許任務入口、41/38/39等流程與正式交付。
- LOCK：只讀鎖定。可看索引/規格/建議，但禁止任務入口與正式交付。

## 指令（全中文）
- 進入系統模式：Xing育昇總務課
- 回到聊天模式
- 鎖定系統：Xing育昇總務課
- 解鎖系統：Xing育昇總務課
- 現在是什麼模式？

## 逾時建議
- SYSTEM 超過 30 分鐘未明確維持，建議回到 NORMAL 以防誤觸。
---

## 原文關鍵摘錄
- "# 總控開關（NORMAL / SYSTEM / LOCK）使用說明"
- "目的：避免誤觸工作流。此為「防呆規則」，不屬真正安全驗證。"
- "## 三種模式"
- "- NORMAL：一般聊天（預設）。不跑任務入口、不做正式交付。"
- "- SYSTEM：系統工作流。允許任務入口、41/38/39等流程與正式交付。"
- "- LOCK：只讀鎖定。可看索引/規格/建議，但禁止任務入口與正式交付。"
- "## 指令（全中文）"
