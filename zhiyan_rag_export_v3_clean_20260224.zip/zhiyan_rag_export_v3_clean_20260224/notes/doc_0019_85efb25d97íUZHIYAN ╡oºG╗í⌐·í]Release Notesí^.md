---
alias: []
tags: [reference_, ZHIYAN, Release, Notes, Asia, Taipei, LITIGATION, persona, SRP, key]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/95_版本更新紀錄_RELEASE_NOTES.md]
sensitivity: medium
---
# ZHIYAN 發佈說明（Release Notes）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [reference_, ZHIYAN, Release, Notes, Asia, Taipei, LITIGATION, persona, SRP, key]
- scope: 95_版本更新紀錄_RELEASE_NOTES.md：ZHIYAN 發佈說明（Release Notes）
- content_type: knowledge
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/95_版本更新紀錄_RELEASE_NOTES.md
- sensitivity: medium
內容：
# ZHIYAN 發佈說明（Release Notes）

## v3.00.3（審計降噪整合修復版）
**發佈日期**：2026-01-17（Asia/Taipei）
**類型**：審計修補／降噪／一致性修復

### 變更摘要（本版重點）
- 修正 LITIGATION 檔案誤用 persona 標籤：改為 `#ZHIYAN_MODULE_LITIGATION_STRATEGY#`。
- 統一 SRP 標頭格式與中文欄位，避免混用英文 key 造成模型誤判。
- 引用規範收斂：`31_引用政策_CITATION_POLICY_v2.0.md` 為唯一真實來源；「引用升級手冊」已封存至 `99_reference_勿載入/`（避免重複定義）。
- 核心規格檔名對齊：`01_智研空間_核心規格_v3.00_HYBRID.md`。
- 入口導覽、README、索引與操作清單全面對齊本包實際檔名與資料夾結構（避免指向不存在路徑）。
- BOOT 新增「人格/模組選擇決策表」；移除未實作的自動轉換/過渡期敘述，降低誤導風險。

### 載入規則（硬性建議）
- ✅ 只掃描/載入：`01_上傳到Space_檔案/`
- ❌ 嚴禁載入：`99_reference_勿載入/`（封存/參考）
- ❌ 嚴禁載入：`98_audit_稽核/`（稽核/Checksum/Tree）

---

## v3.00.2（審計降噪整合版）
- 交付初版整合包；本版已由 v3.00.3 取代。
---

## 原文關鍵摘錄
- "# ZHIYAN 發佈說明（Release Notes）"
- "## v3.00.3（審計降噪整合修復版）"
- "**發佈日期**：2026-01-17（Asia/Taipei）"
- "**類型**：審計修補／降噪／一致性修復"
- "### 變更摘要（本版重點）"
- "- 修正 LITIGATION 檔案誤用 persona 標籤：改為 `#ZHIYAN_MODULE_LITIGATION_STRATEGY#`。"
- "- 統一 SRP 標頭格式與中文欄位，避免混用英文 key 造成模型誤判。"
