---
alias: []
tags: [MASTER, Fact_Check, BOOT, HALT_ALL_DOWNSTREAM, REQUIRE, FAIL, ERROR_MODE, PASS, 人格, 模組]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/ZHIYAN_權限矩陣表_草案.md]
sensitivity: high
---
# ZHIYAN_權限矩陣表_草案
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [MASTER, Fact_Check, BOOT, HALT_ALL_DOWNSTREAM, REQUIRE, FAIL, ERROR_MODE, PASS, 人格, 模組]
- scope: ZHIYAN_權限矩陣表_草案.md：ZHIYAN_權限矩陣表_草案
- content_type: principle
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/ZHIYAN_權限矩陣表_草案.md
- sensitivity: high
內容：
# ZHIYAN_權限矩陣表_草案

## 核心原則

- [[Single Source of Truth]]：BOOT／人格（L1）／模組（L2）共用唯一判斷依據
- 適用順序：核心先 → 路由後 → 人格/模組最後
- 缺失事實需先補齊，未通過則[[中止]]

---

## 權限矩陣（初版）

| 輸入條件 | 風險等級 | 允許人格（L1） | 允許模組（L2） |
|---------|---------|----------------|----------------|
| 名詞／制度解釋（無現案） | 低 | TUTOR | — |
| 申論題（題幹明確） | 中 | WRITER、TA | — |
| 一般問題（需整理回報） | 低～中 | MASTER | — |
| 已驗證事實（可提出多方案） | 中 | CONSULTANT | — |
| 合約文本完整（可起草/審閱） | 中 | LEGAL_WRITER | CONTRACT_RISK（需額外 REQUIRE） |
| 合約不完整（僅能列缺失清單） | 中 | MASTER（缺失清單模式） | — |
| 訴訟現案／攻防推演 | 高 | MASTER（先整理） | LITIGATION（需額外 REQUIRE） |
| 事實缺失（Who/When/Where/What/Result 不足） | 任意 | MASTER（ERROR／補充清單） | — |
| Fact_Check == FAIL | 任意 | MASTER（ERROR_MODE） | — |

---

## 全域硬性規則

1. [[BOOT]] 只允許讀取本矩陣做決策，不得自行複寫入口邏輯
2. 任意[[L2 模組]]必須同時滿足：
   - `CORE_GATE_STATUS == PASS`
   - `CONTEXT_COMPLETENESS == TRUE`
   - `MODULE_PERMISSION == GRANTED`
3. 若 `Fact_Check == FAIL`：
   - 一律中止所有下游（`HALT_ALL_DOWNSTREAM`）
   - 僅允許輸出「錯誤模式／補充清單」

---

## 條件決策流程

```mermaid
flowchart TD
    A[接收輸入條件] --> B{Fact_Check PASS?}
    B -- 否 --> F[HALT_ALL_DOWNSTREAM / ERROR_MODE]
    B -- 是 --> C[確認核心事實完整]
    C -- 否 --> G[MASTER 補充清單模式]
    C -- 是 --> D[查表決定 L1 人格]
    D --> E[符合條件則授權 L2 模組]
    E --> H[完成權限分配]
```

---

## 關鍵概念鏈接

- [[BOOT]]
- [[人格 L1]]
- [[模組 L2]]
- [[Fact_Check]]
- [[HALT_ALL_DOWNSTREAM]]

---

#智研系統 #權限管理 #決策矩陣 #品質檢查
---

## 原文關鍵摘錄
- "# ZHIYAN_權限矩陣表_草案"
- "## 核心原則"
- "- [[Single Source of Truth]]：BOOT／人格（L1）／模組（L2）共用唯一判斷依據"
- "- 適用順序：核心先 → 路由後 → 人格/模組最後"
- "- 缺失事實需先補齊，未通過則[[中止]]"
- "---"
- "## 權限矩陣（初版）"
