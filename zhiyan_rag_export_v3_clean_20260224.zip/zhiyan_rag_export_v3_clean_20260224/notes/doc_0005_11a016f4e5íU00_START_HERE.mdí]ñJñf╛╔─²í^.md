---
alias: []
tags: [Space, HYBRID, 範本, CITATION_POLICY_v2, QC_, RESEARCH_, REPORT_, 指令, 貼到, START_HERE]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [00_智研V2.41_版本.zip, 00_智研法學資料庫｜版本整理系統/00_開始閱讀_入口導覽_v2.1.md]
sensitivity: medium
---
# 00_START_HERE.md（入口導覽）
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [Space, HYBRID, 範本, CITATION_POLICY_v2, QC_, RESEARCH_, REPORT_, 指令, 貼到, START_HERE]
- scope: 00_開始閱讀_入口導覽_v2.1.md：00_START_HERE.md（入口導覽）
- content_type: procedure
- source: 00_智研V2.41_版本.zip:00_智研法學資料庫｜版本整理系統/00_開始閱讀_入口導覽_v2.1.md
- sensitivity: medium
內容：
# 00_START_HERE.md（入口導覽）

**版本**：v2.2（對齊 v3.00.3 審計降噪整合修復版）
**日期**：2026-01-17（Asia/Taipei）
**狀態**：Ready to Upload

---

# 智研 ZHIYAN 系統 — 使用指南（Space 版）

## 快速開始（30 秒）
1) 先看本檔（你正在看）。
2) Space 指令：到 `00_貼到Space_指令/`，把 **01_智研空間指令_貼到Space_v3.00.txt** 整段貼到 Space Instructions。
3) Space 檔案：把 `01_上傳到Space_檔案/` 這一包上傳到 Space Files/Knowledge（作為檢索資料）。

---

## 核心文檔（按優先度）
1) **引用規則（唯一真實來源）**
   - `31_引用政策_CITATION_POLICY_v2.0.md`

2) **主人格與輸出邊界（預設行為）**
   - `10_主人格_MASTER_v2.0.0.md`

3) **系統路由（何時切換模式/人格/模組）**
   - `11_啟動流程_BOOT_v2.40.md`

4) **融合核心規格（v3.00_HYBRID）**
   - `01_智研空間_核心規格_v3.00_HYBRID.md`

5) **融合部署指南（只談怎麼用）**
   - `00_混合部署指南_HYBRID.md`

---

## 三種工作模式（Mode）

### MODE_QC（品質檢查/抓錯）
- 範本：`22_模式_QC_查核_v2.0.md`

### MODE_RESEARCH（查資料/多來源整理）
- 範本：`21_模式_RESEARCH_研究_v2.0.md`

### MODE_REPORT（主管稿/交付版）
- 範本：`20_模式_REPORT_報告_v2.0.md`

---

## 常見問題速查

| 問題 | 答案 | 對應檔案 |
|---|---|---|
| 什麼是新引用格式？ | 文中 [1][2]…；每段末尾【本段資料來源】表格 | 31_引用政策_CITATION_POLICY_v2.0.md |
| 什麼是融合版？ | v3.00_HYBRID：降噪風險、精簡來源、固定優先順序 | 01_智研空間_核心規格_v3.00_HYBRID.md |
| 我想做 QC | 用 QC 範本（抓矛盾、缺口、引用問題） | 22_模式_QC_查核_v2.0.md |
| 我想做研究整理 | 用 RESEARCH 範本（官方/學術/媒體分層） | 21_模式_RESEARCH_研究_v2.0.md |
| 我想出正式報告 | 用 REPORT 範本（主管可讀、可交付） | 20_模式_REPORT_報告_v2.0.md |
| 哪些資料夾不能載入？ | 參考/稽核皆封存，避免主流程漂移 | 03_README_總覽.md |

---

## 目錄結構（你只要記兩個資料夾）

- `00_貼到Space_指令/`：只貼不上傳
- `01_上傳到Space_檔案/`：建議上傳（掃描一載入區）

封存區（不要上傳/不要載入）：
- `98_audit_稽核/`
- `99_reference_勿載入/`
---

## 原文關鍵摘錄
- "# 00_START_HERE.md（入口導覽）"
- "**版本**：v2.2（對齊 v3.00.3 審計降噪整合修復版）"
- "**日期**：2026-01-17（Asia/Taipei）"
- "**狀態**：Ready to Upload"
- "---"
- "# 智研 ZHIYAN 系統 — 使用指南（Space 版）"
- "## 快速開始（30 秒）"
