---
alias: []
tags: [schema, name, description, ChLaw, json, csv, 中文法規法律, 資料檔]
category: 20_⚖️法務智研 Zhiyan/10_知識條目/00_入庫原文
version: 1.0
update: 2026-02-24
type: rag_note
rag: true
source: [智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 娉曞緥澶у叏.zip, manifest.csv]
sensitivity: medium
---
# ﻿name,schema,description
> 核心定位：由原始檔案抽取之 RAG Chunk 入庫筆記（僅供檢索）

## RAG Chunks區塊
---
### Chunk 01
- chunk_id: 01
- keywords: [schema, name, description, ChLaw, json, csv, 中文法規法律, 資料檔]
- scope: manifest.csv：﻿name,schema,description
- content_type: knowledge
- source: 智研系統_V3_BASELINE_20260224_033619.zip > 育昇總務部_v2.38_MERGED_DEDUP.zip > 娉曞緥澶у叏.zip:manifest.csv
- sensitivity: medium
內容：
﻿name,schema,description
ChLaw.json,schema.csv,中文法規法律資料檔
---

## 原文關鍵摘錄
- "﻿name,schema,description"
- "ChLaw.json,schema.csv,中文法規法律資料檔"
